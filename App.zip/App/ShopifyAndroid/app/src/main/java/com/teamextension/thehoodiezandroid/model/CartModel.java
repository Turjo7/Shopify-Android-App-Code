/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.model;

import com.shopify.graphql.support.ID;
import com.teamextension.thehoodiezandroid.managers.DataManagerHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CartModel {

    private HashMap<String, ArrayList<String>> mVariants = null;

    public CartModel() {
        mVariants = new HashMap<String, ArrayList<String>>();
    }

    public synchronized ArrayList<String> getVariantsForProduct(String productID) {
        return mVariants.get(productID);
    }

    public synchronized ArrayList<CartItemWrapper> getCartProducts() {
        ArrayList<CartItemWrapper> result = new ArrayList<CartItemWrapper>();
        for(Map.Entry<String, ArrayList<String>> entry: mVariants.entrySet()) {
            ProductModel product = DataManagerHelper.getInstance().getProductByID(entry.getKey());
            for(String variantId: mVariants.get(product.getID().toString())) {
                ProductModel.ProductVariantModel variant = DataManagerHelper.getInstance().getVariantByID(variantId);
                if(variant != null) {
                    CartItemWrapper newItem = new CartItemWrapper(variant);
                    result.add(newItem);
                }
            }
        }

        return result;
    }

    /**
     * Only the IDs of the products and product variants will be stored inside the CartModel as it is all the
     * required data in order to correctly track down a Product Variant.
     *
     * @param variantId ID of the Product Variant
     */
    public synchronized void remove(ID variantId) {
        ProductModel.ProductVariantModel variant = DataManagerHelper.getInstance().getVariantByID(variantId.toString());

        mVariants.get(variant.getProductID()).remove(variant.getID().toString());
        if (mVariants.get(variant.getProductID()).size() == 0) {
            mVariants.remove(variant.getProductID());
        }

    }

    public synchronized void add(ID variantID) {
        ProductModel.ProductVariantModel variant = DataManagerHelper.getInstance().getVariantByID(variantID.toString());
        ProductModel product = DataManagerHelper.getInstance().getProductByID(variant.getProductID());

        if(mVariants.containsKey(product.getID().toString())) {
            mVariants.get(product.getID().toString()).add(variantID.toString());
        } else {
            ArrayList<String> prodEntries = new ArrayList<String>();
            prodEntries.add(variantID.toString());
            mVariants.put(product.getID().toString(), prodEntries);
        }
    }


    public class CartItemWrapper {
        private ProductModel.ProductVariantModel mVariant = null;

        CartItemWrapper(ProductModel.ProductVariantModel variant) {
            mVariant = variant;
        }

        public ProductModel.ProductVariantModel getProduct() {
            return mVariant;
        }
    }
}
