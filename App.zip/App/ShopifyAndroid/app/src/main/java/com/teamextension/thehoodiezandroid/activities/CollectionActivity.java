/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.activities;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.ArraySet;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;

import com.shopify.graphql.support.ID;
import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.managers.DataManagerHelper;
import com.teamextension.thehoodiezandroid.managers.interfaces.NavigationInterface;
import com.teamextension.thehoodiezandroid.model.CollectionModel;
import com.teamextension.thehoodiezandroid.model.ProductModel;
import com.teamextension.thehoodiezandroid.model.SelectedOptions;
import com.teamextension.thehoodiezandroid.views.adapters.CollectionAdapter;
import com.teamextension.thehoodiezandroid.views.adapters.GridViewAdapter;
import com.teamextension.thehoodiezandroid.views.adapters.PopupFilterAdapter;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public class CollectionActivity extends AbstractActivity implements NavigationInterface {

    private static final String SHOP_CURRENCY = DataManager.getInstance().getShopCurrency();

    private ArrayList<ProductModel> data = null;
    private ArrayList<ProductModel> products = null;

    private static ArrayList<String> prodNames = new ArrayList<String>();
    private CollectionAdapter adapter;
    private GridViewAdapter gridAdapter;
    static final int VIEW_MODE_LISTVIEW = 0;
    static final int VIEW_MODE_GRIDVIEW = 1;
    private int currentViewMode = 0;
    private ID collectionId;
    private ViewStub list;
    private ViewStub grid;
    private ListView listView;
    private GridView gridView;
    private Toolbar toolbar;
    private SharedPreferences sharedPreferences;
    private ImageView searchCloseIcon;
    private MenuItem searchMenuItem = null;
    private SelectedOptions selectedOptions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collection);

        list = findViewById(R.id.list);
        grid = findViewById(R.id.grid);

        selectedOptions = new SelectedOptions();

        collectionId = new ID(getIntent().getStringExtra("collectionId"));

        CollectionModel collection = DataManager.getInstance().getCollectionByID(collectionId.toString());
        data = collection.getPreviewProducts();
        products = data;

        for (int i = 0; i < products.size(); i++) {
            prodNames.add(products.get(i).getTitle());
        }

        //region Toolbar setup
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        TextView title = toolbar.findViewById(R.id.title);
        title.setText(collection.getTitle());

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(CollectionActivity.this);
        sharedPreferences.edit().clear().apply();
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sharedPreferences.edit().clear().apply();
                finish();
            }
        });

        //endregion

        list.inflate();
        grid.inflate();
        listView = findViewById(R.id.collectionListView);
        gridView = findViewById(R.id.collectionGridView);

        SharedPreferences sharedPreferences = getSharedPreferences("ViewMode", MODE_PRIVATE);
        currentViewMode = sharedPreferences.getInt("currentViewMode", VIEW_MODE_LISTVIEW);

        swithView();
        listView.setOnItemClickListener(adapter);
        gridView.setOnItemClickListener(gridAdapter);

        Button sortBy = findViewById(R.id.sortByBtn);
        Button filter = findViewById(R.id.filterBtn);

        sortBy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialogSortby();
            }
        });

        filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                products = data;
                showDialogFilter();
            }
        });

        ImageButton gridViewButton = findViewById(R.id.gridViewBtn);
        gridViewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (VIEW_MODE_LISTVIEW == currentViewMode) {
                    currentViewMode = VIEW_MODE_GRIDVIEW;
                    gridViewButton.setImageResource(R.drawable.ic_view_list_black_24dp);
                } else {
                    currentViewMode = VIEW_MODE_LISTVIEW;
                    gridViewButton.setImageResource(R.drawable.ic_grid_black_24dp);
                }
                swithView();
                SharedPreferences sharedPreferences = getSharedPreferences("ViewMode", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("currentViewMode", currentViewMode);
                editor.apply();
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.search_menu, menu);
        searchMenuItem = menu.findItem(R.id.search);
        MenuItem cartBtn = menu.findItem(R.id.cartBtn);
        cartBtn.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                item.setEnabled(false);
                if(DataManagerHelper.getInstance().getCartProducts().size() == 0) {
                    CollectionActivity.this.showOnUiThread("Cart Is Empty");
                    item.setEnabled(true);
                } else {
                    Intent navigate = new Intent(CollectionActivity.this, CartActivity.class);
                    startActivity(navigate);
                }
                return true;
            }
        });

        SearchView searchView = (SearchView) searchMenuItem.getActionView();
        searchCloseIcon = searchView.findViewById(android.support.v7.appcompat.R.id.search_close_btn);
        searchCloseIcon.setImageResource(R.drawable.ic_clear_black_24dp);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                selectedOptions.setSearchCriteria(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                selectedOptions.setSearchCriteria(newText);
                return true;
            }
        });
        return true;
    }


    AdapterView.OnItemClickListener onItemClick = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            navigateToProduct(products.get(position).getID().toString());
        }
    };

    private void swithView() {
        if (VIEW_MODE_LISTVIEW == currentViewMode) {
            list.setVisibility(View.VISIBLE);
            grid.setVisibility(View.GONE);
        } else {
            list.setVisibility(View.GONE);
            grid.setVisibility(View.VISIBLE);
        }
        setAdapters();
    }

    private void setAdapters() {
        adapter = new CollectionAdapter(this, products);
        selectedOptions.addObserver(adapter);
        listView.setAdapter(adapter);
        gridAdapter = new GridViewAdapter(this, products);
        selectedOptions.addObserver(gridAdapter);
        gridView.setAdapter(gridAdapter);
    }

    @Override
    public void navigateToProduct(String productId) {
        Intent intent = new Intent(CollectionActivity.this, ProductDetailsActivity.class);
        intent.putExtra("productId", productId);
        startActivity(intent);
    }

    @Override
    public void navigateToCollection(String collectionId) {
        //Do nothing
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void showDialogSortby() {
        int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.8);
        int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.5);

        final Dialog dialog = new Dialog(this);
        dialog.getWindow().setLayout(width, height);


        dialog.setTitle(R.string.sort_by_title);
        dialog.setContentView(R.layout.popup_sortby);
        TextView name = dialog.findViewById(R.id.name);
        TextView reverseName = dialog.findViewById(R.id.reverseName);
        TextView oldToNewProds = dialog.findViewById(R.id.oldToNewProds);
        TextView newToOldProds = dialog.findViewById(R.id.newToOldProds);
        TextView highToLowPrice = dialog.findViewById(R.id.highToLow);
        TextView lowToHighPrice = dialog.findViewById(R.id.lowToHigh);
        TextView none = dialog.findViewById(R.id.none);

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(CollectionActivity.this);
        name.setBackgroundResource(sharedPreferences.getInt("textViewColor1", R.color.primary_color_light));
        reverseName.setBackgroundResource(sharedPreferences.getInt("textViewColor2", 0));
        oldToNewProds.setBackgroundResource(sharedPreferences.getInt("textViewColor3", 0));
        newToOldProds.setBackgroundResource(sharedPreferences.getInt("textViewColor4", 0));
        lowToHighPrice.setBackgroundResource(sharedPreferences.getInt("textViewColor6", 0));
        highToLowPrice.setBackgroundResource(sharedPreferences.getInt("textViewColor5", 0));
        none.setBackgroundResource(sharedPreferences.getInt("textViewColor7", 0));
        sharedPreferences.edit().clear().apply();


        name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SharedPreferences sharedPreferences1 = PreferenceManager.getDefaultSharedPreferences(CollectionActivity.this);
                SharedPreferences.Editor editor = sharedPreferences1.edit();
                editor.putInt("textViewColor1", R.color.secondary_color_light);
                editor.apply();
                adapter.sortAtoZ();
                gridAdapter.sortAtoZ();
                dialog.dismiss();
            }
        });
        reverseName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SharedPreferences sharedPreferences1 = PreferenceManager.getDefaultSharedPreferences(CollectionActivity.this);
                SharedPreferences.Editor editor = sharedPreferences1.edit();
                editor.putInt("textViewColor2", R.color.secondary_color_light);
                editor.apply();
                adapter.sortZtoA();
                gridAdapter.sortZtoA();
                dialog.dismiss();
            }
        });
        oldToNewProds.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SharedPreferences sharedPreferences1 = PreferenceManager.getDefaultSharedPreferences(CollectionActivity.this);
                SharedPreferences.Editor editor = sharedPreferences1.edit();
                editor.putInt("textViewColor3", R.color.secondary_color_light);
                editor.apply();
                adapter.sortOldtoNew();
                gridAdapter.sortOldtoNew();
                dialog.dismiss();
            }

        });
        newToOldProds.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SharedPreferences sharedPreferences1 = PreferenceManager.getDefaultSharedPreferences(CollectionActivity.this);
                SharedPreferences.Editor editor = sharedPreferences1.edit();
                editor.putInt("textViewColor4", R.color.secondary_color_light);
                editor.apply();
                adapter.sortNewtoOld();
                gridAdapter.sortNewtoOld();
                dialog.dismiss();
            }

        });
        highToLowPrice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SharedPreferences sharedPreferences1 = PreferenceManager.getDefaultSharedPreferences(CollectionActivity.this);
                SharedPreferences.Editor editor = sharedPreferences1.edit();
                editor.putInt("textViewColor5", R.color.secondary_color_light);
                editor.apply();
                adapter.sortHighToLow();
                gridAdapter.sortHighToLow();
                dialog.dismiss();
            }

        });
        lowToHighPrice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPreferences1 = PreferenceManager.getDefaultSharedPreferences(CollectionActivity.this);
                SharedPreferences.Editor editor = sharedPreferences1.edit();
                editor.putInt("textViewColor6", R.color.secondary_color_light);
                editor.apply();
                adapter.sortLowToHigh();
                gridAdapter.sortLowToHigh();
                dialog.dismiss();
            }

        });

        none.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedOptions.setLowerPrice(0.0);
                selectedOptions.setHigherPrice(0.0);
                selectedOptions.setSize("");
                selectedOptions.setColor("");
                selectedOptions.setMaterial("");
                SharedPreferences sharedPreferences1 = PreferenceManager.getDefaultSharedPreferences(CollectionActivity.this);
                SharedPreferences.Editor editor = sharedPreferences1.edit();
                editor.putInt("textViewColor7", R.color.secondary_color_light);
                editor.apply();
                products = data;
                adapter.setData(products);
                gridAdapter.setData(products);
                dialog.dismiss();
            }
        });
        dialog.show();
    }



    public void showDialogFilter() {
        final Dialog dialog = new Dialog(this);
        dialog.setTitle(R.string.filter_title);
        dialog.setContentView(R.layout.popup_for_filter);
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.copyFrom(dialog.getWindow().getAttributes());
        layoutParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
        layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        dialog.getWindow().setAttributes(layoutParams);

        ListView filterList = dialog.findViewById(R.id.filterList);
        PopupFilterAdapter filterAdapter = new PopupFilterAdapter(this, products, selectedOptions);
        filterList.setAdapter(filterAdapter);

        TextView price = dialog.findViewById(R.id.price);
        TextView selectedPrice = dialog.findViewById(R.id.selectedPrice);
        TextView deleteFilters = dialog.findViewById(R.id.deleteFilters);

        deleteFilters.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                products = data;
                selectedOptions.setLowerPrice(0.0);
                selectedOptions.setHigherPrice(0.0);
                selectedOptions.setSize("");
                selectedOptions.setColor("");
                selectedOptions.setMaterial("");
                filterAdapter.notifyDataSetChanged();
                sharedPreferences.edit().clear().apply();
                selectedPrice.setText("");
            }
        });
        if(selectedOptions.getLowerPrice() == 0.0 || selectedOptions.getHigherPrice() == 0.0) {
            selectedPrice.setText("");
        } else{
            selectedPrice.setText(String.valueOf(selectedOptions.getLowerPrice()) + " - " + String.valueOf(selectedOptions.getHigherPrice() + " " + SHOP_CURRENCY));
        }
        price.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                products = data;
                final Dialog priceDialog = new Dialog(CollectionActivity.this);

                priceDialog.setContentView(R.layout.popup_price_filter);

                Objects.requireNonNull(priceDialog.getWindow()).setLayout(dialog.getWindow().getDecorView().getWidth(),  dialog.getWindow().getDecorView().getHeight());

                Set<BigDecimal> prices = new ArraySet<>();

                Set<BigDecimal> newPrices = new ArraySet<>();
                for (ProductModel product : products) {
                    prices.add(product.getPrice());
                }
                BigDecimal lowestPrice = Collections.min(prices);
                BigDecimal highestPrice = Collections.max(prices);
                    Double p = (highestPrice.doubleValue() - lowestPrice.doubleValue())/5;

                    for(double i = lowestPrice.doubleValue(); i <= highestPrice.doubleValue() - p; i += p){
                            newPrices.add(BigDecimal.valueOf(i).setScale(2, RoundingMode.HALF_UP));
                    }
                        newPrices.add(highestPrice);

                ImageView backArrow = priceDialog.findViewById(R.id.backArrow1);
                backArrow.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        priceDialog.dismiss();
                        dialog.show();
                    }
                });


                LinearLayout layout = priceDialog.findViewById(R.id.radioGroupLayout);
                ArrayList<RadioButton> radioButtons = new ArrayList<>();
                for (int i = 0; i < newPrices.size() - 1; i++) {

                    LinearLayout linearLayout = new LinearLayout(getApplicationContext());
                    RadioButton radioButton = new RadioButton(getApplicationContext());
                    radioButtons.add(radioButton);

                    TextView quantity = new TextView(getApplicationContext());
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);

                    linearLayout.setOrientation(LinearLayout.HORIZONTAL);
                    linearLayout.setPadding(0, 25, 8, 25);
                    linearLayout.setLayoutParams(layoutParams);
                    List pricesList = new ArrayList<BigDecimal>(newPrices);

                    Double lowerValue = Double.valueOf(pricesList.get(i + 1).toString());
                    Double higherValue = Double.valueOf(pricesList.get(i).toString());
                    ArrayList<ProductModel> priceProducts = new ArrayList<>();
                    for (ProductModel product : products) {
                        if (i+1 < newPrices.size() && product.getPrice().doubleValue() <= Double.valueOf(pricesList.get(i+1).toString()) && product.getPrice().doubleValue() >= Double.valueOf(pricesList.get(i).toString())) {
                            priceProducts.add(product);
                        }
                    }
                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                            100, LinearLayout.LayoutParams.MATCH_PARENT, 1);
                    params.setMargins(10, 10, 10, 10);
                    quantity.setLayoutParams(params);
                    quantity.setText(String.valueOf(priceProducts.size()));
                    quantity.setTextColor(getColor(R.color.primary_color_light));
                    quantity.setPadding(0, 10, 0, 10);
                    quantity.setGravity(Gravity.CENTER);
                    quantity.setBackgroundResource(R.color.tertiary_color_dark);
                    if(i + 1 < newPrices.size()) {
                        radioButton.setText(pricesList.get(i).toString() + " - " + pricesList.get(i + 1).toString() + " " + SHOP_CURRENCY);

                    }
                    radioButton.setTag(i);
                    ColorStateList colorStateList = new ColorStateList(
                            new int[][]{
                                    new int[]{-android.R.attr.state_enabled},
                                    new int[]{android.R.attr.state_enabled}
                            },
                            new int[] {Color.BLACK ,Color.BLACK}
                    );
                    radioButton.setButtonTintList(colorStateList);
                    radioButton.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT, 9));
                    radioButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int tag = (int) v.getTag();
                            for (int j = 0; j < radioButtons.size(); j++) {
                                if (j != tag) {
                                    radioButtons.get(j).setChecked(false);

                                }
                            }

                            sharedPreferences = PreferenceManager.getDefaultSharedPreferences(CollectionActivity.this);
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putInt("priceTag", tag);
                            editor.apply();

                            selectedOptions.setHigherPrice(lowerValue);
                            selectedOptions.setLowerPrice(higherValue);
                            selectedPrice.setText(String.valueOf(selectedOptions.getLowerPrice()) + " - " + String.valueOf(selectedOptions.getHigherPrice() + " " + SHOP_CURRENCY));
                            selectedOptions.notifyObservers();
                            dialog.dismiss();
                        }
                    });
                    radioButton.setTextColor(getColor(R.color.primary_color_dark));
                    linearLayout.setWeightSum(10);
                    linearLayout.addView(radioButton, 0);
                    linearLayout.addView(quantity, 1);
                    View line = new View(getApplicationContext());
                    line.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,3 ));
                    line.setBackgroundColor(getColor(R.color.secondary_color_light));
                    layout.addView(linearLayout);
                    layout.addView(line);
                }

                sharedPreferences = PreferenceManager.getDefaultSharedPreferences(CollectionActivity.this);
                int j = sharedPreferences.getInt("priceTag", -1);
                if (j >= 0 && j <= radioButtons.size()) {
                    radioButtons.get(j).setChecked(true);
                }
                priceDialog.show();
            }
        });

        filterList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView filterName = view.findViewById(R.id.filterName);
                String name = filterName.getText().toString();
                HashMap<String, Set<String>> options;
                options = new HashMap<String, Set<String>>();
                products = data;
                for (int i = 0; i < products.size(); i++) {
                    for (ProductModel.ProductVariantModel variant : products.get(i).getVariants()) {
                        for (Map.Entry<String, String> entry : variant.getSelectedOptions().entrySet()) {
                            if (options.containsKey(entry.getKey())) {
                                options.get(entry.getKey()).add(entry.getValue());
                            } else {
                                options.put(entry.getKey(), new android.support.v4.util.ArraySet<String>());
                                options.get(entry.getKey()).add(entry.getValue());
                            }
                        }
                    }
                }

                Set<String> sizes = new ArraySet<>();
                Set<String> colors = new ArraySet<>();
                Set<String> materials = new ArraySet<>();
                        for (Map.Entry<String, Set<String>> entry : options.entrySet()) {
                            for (String s : entry.getValue()) {
                                if (entry.getKey().equals("Size")) {
                                    sizes.add(s);
                                }
                                if (entry.getKey().equals("Color")) {
                                    colors.add(s);
                                }
                                if (entry.getKey().equals("Material")) {
                                    materials.add(s);
                                }

                            }

                    }


                switch (name) {
                    case "Size": {

                        final Dialog sizeDialog = new Dialog(CollectionActivity.this);
                        sizeDialog.setContentView(R.layout.popup_size_filter);
                        Objects.requireNonNull(sizeDialog.getWindow()).setLayout(dialog.getWindow().getDecorView().getWidth(), dialog.getWindow().getDecorView().getHeight());
                        ImageView backArrow = sizeDialog.findViewById(R.id.backArrow);
                        backArrow.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                sizeDialog.dismiss();
                                dialog.show();
                            }
                        });

                        LinearLayout layout = sizeDialog.findViewById(R.id.rgLayout);
                        ArrayList<RadioButton> radioButtons = new ArrayList<>();
                        List sizesList = new ArrayList<>(sizes);
                        for (int i = 0; i < sizes.size(); i++) {
                            LinearLayout linearLayout = new LinearLayout(getApplicationContext());
                            RadioButton radioButton = new RadioButton(getApplicationContext());
                            radioButtons.add(radioButton);
                            TextView quantity = new TextView(getApplicationContext());
                            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);

                            layoutParams.gravity = Gravity.CENTER;
                            linearLayout.setOrientation(LinearLayout.HORIZONTAL);
                            linearLayout.setPadding(0, 25, 8, 25);
                            linearLayout.setLayoutParams(layoutParams);

                            radioButton.setText(sizesList.get(i).toString());
                            radioButton.setTextColor(getColor(R.color.primary_color_dark));
                            quantity.setTextColor(getColor(R.color.primary_color_light));
                            quantity.setPadding(50, 1, 50, 1);
                            quantity.setGravity(Gravity.CENTER);
                            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                                    100, LinearLayout.LayoutParams.MATCH_PARENT, 1);
                            params.setMargins(10, 10, 10, 10);
                            quantity.setLayoutParams(params);
                            quantity.setBackgroundResource(R.color.tertiary_color_dark);
                            String sortValue = radioButton.getText().toString();
                            ArrayList<ProductModel> filtered = new ArrayList<>();
                            for (ProductModel prod : products) {
                                for (ProductModel.ProductVariantModel variant : prod.getVariants()) {
                                    for (Map.Entry<String, String> entry : variant.getSelectedOptions().entrySet()) {
                                        if (entry.getValue().equals(sortValue)) {
                                            if (!filtered.contains(prod)) {
                                                filtered.add(prod);
                                            }
                                        }
                                    }
                                }
                            }

                            quantity.setText(String.valueOf(filtered.size()));
                            radioButton.setTag(i);
                            ColorStateList colorStateList = new ColorStateList(
                                    new int[][]{
                                            new int[]{-android.R.attr.state_enabled},
                                            new int[]{android.R.attr.state_enabled}
                                    },
                                    new int[]{Color.BLACK, Color.BLACK}
                            );
                            radioButton.setButtonTintList(colorStateList);
                            radioButton.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT, 9));
                            radioButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    int tag = (int) v.getTag();
                                    products = filtered;
                                    for (int j = 0; j < radioButtons.size(); j++) {
                                        if (j != tag) {
                                            radioButtons.get(j).setChecked(false);
                                        }
                                    }
                                    sharedPreferences = PreferenceManager.getDefaultSharedPreferences(CollectionActivity.this);
                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.putInt("sizeTag", tag);
                                    editor.apply();
                                    selectedOptions.setSize(radioButtons.get(tag).getText().toString());
                                    filterAdapter.notifyDataSetChanged();
                                }
                            });

                            linearLayout.setWeightSum(10);
                            linearLayout.addView(radioButton, 0);
                            linearLayout.addView(quantity, 1);
                            View line = new View(getApplicationContext());
                            line.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 3));
                            line.setBackgroundColor(getColor(R.color.secondary_color_light));
                            layout.addView(linearLayout);
                            layout.addView(line);
                        }
                        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(CollectionActivity.this);
                        int j = sharedPreferences.getInt("sizeTag", -1);
                        if (j >= 0) {
                            radioButtons.get(j).setChecked(true);
                        }

                        sizeDialog.show();
                        break;
                    }
                    case "Color": {
                        final Dialog colorDialog = new Dialog(CollectionActivity.this);

                        colorDialog.setContentView(R.layout.popup_color_filter);
                        Objects.requireNonNull(colorDialog.getWindow()).setLayout(dialog.getWindow().getDecorView().getWidth(), dialog.getWindow().getDecorView().getHeight());

                        ImageView backArrow = colorDialog.findViewById(R.id.backArrow3);
                        backArrow.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                colorDialog.dismiss();
                                dialog.show();
                            }
                        });
                        LinearLayout layout = colorDialog.findViewById(R.id.radioLayout);
                        ArrayList<RadioButton> radioButtons = new ArrayList<>();
                        List colorsList = new ArrayList<>(colors);
                        for (int i = 0; i < colors.size(); i++) {
                            LinearLayout linearLayout = new LinearLayout(getApplicationContext());
                            RadioButton radioButton = new RadioButton(getApplicationContext());
                            radioButtons.add(radioButton);
                            TextView quantity = new TextView(getApplicationContext());
                            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);

                            linearLayout.setOrientation(LinearLayout.HORIZONTAL);
                            linearLayout.setPadding(0, 25, 8, 25);
                            linearLayout.setLayoutParams(layoutParams);


                            radioButton.setText(colorsList.get(i).toString());
                            radioButton.setTextColor(getColor(R.color.primary_color_dark));
                            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                                    100, LinearLayout.LayoutParams.MATCH_PARENT, 1);
                            params.setMargins(10, 10, 10, 10);
                            quantity.setLayoutParams(params);

                            quantity.setTextColor(getColor(R.color.primary_color_light));
                            quantity.setPadding(0, 10, 0, 10);
                            quantity.setGravity(Gravity.CENTER);
                            quantity.setBackgroundResource(R.color.tertiary_color_dark);
                            String sortValue = radioButton.getText().toString();
                            ArrayList<ProductModel> filtered = new ArrayList<>();
                            for (ProductModel prod : products) {
                                for (ProductModel.ProductVariantModel variant : prod.getVariants()) {
                                    for (Map.Entry<String, String> entry : variant.getSelectedOptions().entrySet()) {
                                        if (entry.getValue().equals(sortValue)) {
                                            if (!filtered.contains(prod)) {
                                                filtered.add(prod);
                                            }
                                        }
                                    }
                                }
                            }
                            quantity.setText(String.valueOf(filtered.size()));
                            radioButton.setTag(i);
                            ColorStateList colorStateList = new ColorStateList(
                                    new int[][]{
                                            new int[]{-android.R.attr.state_enabled},
                                            new int[]{android.R.attr.state_enabled}
                                    },
                                    new int[]{Color.BLACK, Color.BLACK}
                            );
                            radioButton.setButtonTintList(colorStateList);
                            radioButton.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT, 9));
                            radioButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    products = filtered;
                                    int tag = (int) v.getTag();
                                    for (int j = 0; j < radioButtons.size(); j++) {
                                        if (j != tag) {
                                            radioButtons.get(j).setChecked(false);
                                        }
                                    }
                                    sharedPreferences = PreferenceManager.getDefaultSharedPreferences(CollectionActivity.this);
                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.putInt("colorTag", tag);
                                    editor.apply();
                                    selectedOptions.setColor(radioButtons.get(tag).getText().toString());
                                    dialog.dismiss();
                                }
                            });
                            linearLayout.setWeightSum(10);
                            linearLayout.addView(radioButton, 0);
                            linearLayout.addView(quantity, 1);
                            View line = new View(getApplicationContext());
                            line.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 3));
                            line.setBackgroundColor(getColor(R.color.secondary_color_light));
                            layout.addView(linearLayout);
                            layout.addView(line);
                        }
                        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(CollectionActivity.this);
                        int j = sharedPreferences.getInt("colorTag", -1);
                        if (j >= 0) {
                            radioButtons.get(j).setChecked(true);
                        }
                        colorDialog.show();
                        break;
                    }
                    case "Material": {
                        final Dialog materialDialog = new Dialog(CollectionActivity.this);

                        materialDialog.setContentView(R.layout.popup_material_filter);
                        Objects.requireNonNull(materialDialog.getWindow()).setLayout(dialog.getWindow().getDecorView().getWidth(), dialog.getWindow().getDecorView().getHeight());
                        ImageView backArrow = materialDialog.findViewById(R.id.backArrow4);
                        backArrow.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                materialDialog.dismiss();
                                dialog.show();
                            }
                        });
                        LinearLayout layout = materialDialog.findViewById(R.id.radLayout);
                        ArrayList<RadioButton> radioButtons = new ArrayList<>();
                        List lst = new ArrayList<>(materials);
                        for (int i = 0; i < materials.size(); i++) {
                            LinearLayout linearLayout = new LinearLayout(getApplicationContext());
                            RadioButton radioButton = new RadioButton(getApplicationContext());
                            radioButtons.add(radioButton);
                            TextView quantity = new TextView(getApplicationContext());

                            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);

                            layoutParams.gravity = Gravity.CENTER;
                            linearLayout.setOrientation(LinearLayout.HORIZONTAL);
                            linearLayout.setPadding(0, 25, 8, 25);
                            linearLayout.setLayoutParams(layoutParams);
                            radioButton.setText(lst.get(i).toString());
                            radioButton.setTextColor(getColor(R.color.primary_color_dark));
                            quantity.setTextColor(getColor(R.color.primary_color_light));
                            quantity.setPadding(50, 1, 50, 1);
                            quantity.setGravity(Gravity.CENTER);
                            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                                    100, LinearLayout.LayoutParams.MATCH_PARENT, 1);
                            params.setMargins(10, 10, 10, 10);
                            quantity.setLayoutParams(params);
                            quantity.setBackgroundResource(R.color.tertiary_color_dark);
                            String sortValue = radioButton.getText().toString();
                            ArrayList<ProductModel> filtered = new ArrayList<>();
                            for (ProductModel prod : products) {
                                for (ProductModel.ProductVariantModel variant : prod.getVariants()) {
                                    for (Map.Entry<String, String> entry : variant.getSelectedOptions().entrySet()) {
                                        if (entry.getValue().equals(sortValue)) {
                                            if (!filtered.contains(prod)) {
                                                filtered.add(prod);
                                            }
                                        }
                                    }
                                }
                            }
                            quantity.setText(String.valueOf(filtered.size()));
                            radioButton.setTag(i);
                            ColorStateList colorStateList = new ColorStateList(
                                    new int[][]{
                                            new int[]{-android.R.attr.state_enabled},
                                            new int[]{android.R.attr.state_enabled}
                                    },
                                    new int[]{Color.BLACK, Color.BLACK}
                            );
                            radioButton.setButtonTintList(colorStateList);
                            radioButton.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT, 9));
                            radioButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    products = filtered;
                                    int tag = (int) v.getTag();
                                    for (int j = 0; j < radioButtons.size(); j++) {
                                        if (j != tag) {
                                            radioButtons.get(j).setChecked(false);
                                        }
                                    }
                                    sharedPreferences = PreferenceManager.getDefaultSharedPreferences(CollectionActivity.this);
                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.putInt("materialTag", tag);
                                    editor.apply();
                                    selectedOptions.setMaterial(radioButtons.get(tag).getText().toString());
                                    dialog.dismiss();
                                }
                            });
                            linearLayout.setWeightSum(10);
                            linearLayout.addView(radioButton, 0);
                            linearLayout.addView(quantity, 1);
                            View line = new View(getApplicationContext());
                            line.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 3));
                            line.setBackgroundColor(getColor(R.color.secondary_color_light));
                            layout.addView(linearLayout);
                            layout.addView(line);
                        }
                        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(CollectionActivity.this);
                        int j = sharedPreferences.getInt("materialTag", -1);
                        if (j >= 0) {
                            radioButtons.get(j).setChecked(true);
                        }
                        materialDialog.show();
                        break;
                    }
                }
            }
        });
        dialog.show();
    }
}

