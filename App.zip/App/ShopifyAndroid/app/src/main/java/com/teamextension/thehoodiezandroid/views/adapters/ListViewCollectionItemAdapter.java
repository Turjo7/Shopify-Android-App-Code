/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.views.adapters;

import android.app.Activity;
import android.content.Context;
import android.graphics.Paint;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.activities.MainActivity;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.managers.interfaces.NavigationInterface;
import com.teamextension.thehoodiezandroid.model.ProductModel;

import java.util.ArrayList;


public class ListViewCollectionItemAdapter extends RecyclerView.Adapter<ListViewCollectionItemAdapter.SingleItemRowHolder>{

    private static final String SHOP_CURRENCY = DataManager.getInstance().getShopCurrency();

    private ArrayList<ProductModel> itemsList = new ArrayList<ProductModel>();
    private ArrayList<ProductModel> previewData = new ArrayList<ProductModel>();
    private Context mContext = null;
    private DisplayMetrics mDm = null;
    private NavigationInterface mCallback = null;

    ListViewCollectionItemAdapter(Context context, ArrayList<ProductModel> previewData){
        this.itemsList = previewData;
        if(this.itemsList.size() > 9) {
            this.previewData.addAll(this.itemsList.subList(0, 10));
        } else {
            this.previewData = this.itemsList;
        }
        this.mContext = context;
        if(context instanceof MainActivity) {
            mCallback =((MainActivity) context);
        }
        mDm = new DisplayMetrics();
    }
    @NonNull
    @Override
    public SingleItemRowHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.listview_collection_item, null);

        ((Activity) mContext).getWindowManager().getDefaultDisplay().getMetrics(mDm);
        ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(mDm.widthPixels / 3, mDm.widthPixels / 2);
        params.setMargins(24, 0, 24, 8);

        v.setLayoutParams(params);

        return new SingleItemRowHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull SingleItemRowHolder holder, int position) {
        ProductModel singleItem = itemsList.get(position);

        holder.bind(singleItem, position, mCallback);
    }

    @Override
    public int getItemCount() {
        if(this.previewData.size() != this.itemsList.size()) {
            return (null != this.previewData ? this.previewData.size() + 1: 0);
        } else {
            return (null != this.previewData ? this.previewData.size(): 0);
        }
    }

    public class SingleItemRowHolder extends RecyclerView.ViewHolder {

        protected TextView productTitle = null;
        protected ImageView image = null;
        protected TextView oldPrice = null;
        protected TextView newPrice = null;
        protected TextView label = null;

        SingleItemRowHolder(View view) {
            super(view);

            this.productTitle = view.findViewById(R.id.productTitle);
            this.image = view.findViewById(R.id.itemImage);
            this.oldPrice = view.findViewById(R.id.oldPrice);
            this.newPrice = view.findViewById(R.id.newPrice);
            this.label = view.findViewById(R.id.label);

            this.label.setWidth(mDm.widthPixels / 8);

            this.newPrice.setVisibility(View.INVISIBLE);
        }

        void bind(final ProductModel singleItem, int position, NavigationInterface callback){
            if(position > 9) {
                this.image.setVisibility(View.GONE);
                this.productTitle.setText(R.string.see_more_products_text);
                this.oldPrice.setText("");
                this.newPrice.setText("");
                this.label.setVisibility(View.GONE);
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        callback.navigateToCollection(singleItem.getCollectionID());
                    }
                });
                return;
            }

            this.image.setVisibility(View.VISIBLE);
            this.productTitle.setText(singleItem.getTitle());
            Picasso.with(mContext)
                    .load(singleItem.getImages()[0])
                    .fit()
                    .into(this.image);

            if(singleItem.getVariants().get(0).getOldPrice() != null &&
                    singleItem.getVariants().get(0).getOldPrice().compareTo(singleItem.getVariants().get(0).getPrice()) > 0 &&
                    singleItem.getVariants().get(0).isAvailableForSale()) {
                this.oldPrice.setText(singleItem.getVariants().get(0).getOldPrice().toString() + ' ' +
                        SHOP_CURRENCY);
                this.oldPrice.setPaintFlags(this.oldPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                this.newPrice.setVisibility(View.VISIBLE);
                this.label.setVisibility(View.VISIBLE);
                this.label.setText(R.string.sale_text);
                this.newPrice.setText(singleItem.getVariants().get(0).getPrice().toString() + ' ' +
                        SHOP_CURRENCY);
            }  else {
                this.newPrice.setVisibility(View.INVISIBLE);
                this.oldPrice.setVisibility(View.VISIBLE);
                this.label.setVisibility(View.INVISIBLE);
                this.oldPrice.setText(singleItem.getVariants().get(0).getPrice().toString() + ' ' +
                        SHOP_CURRENCY);
            }

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    callback.navigateToProduct(singleItem.getID().toString());
                }
            });
        }

    }
}
