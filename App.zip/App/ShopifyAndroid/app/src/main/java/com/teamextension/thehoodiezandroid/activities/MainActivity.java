/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.support.v7.widget.SearchView;
import android.widget.TextView;

import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.managers.DataManagerHelper;
import com.teamextension.thehoodiezandroid.managers.interfaces.BaseCallback;
import com.teamextension.thehoodiezandroid.managers.interfaces.NavigationInterface;
import com.teamextension.thehoodiezandroid.model.CollectionModel;
import com.teamextension.thehoodiezandroid.model.CurrentUser;
import com.teamextension.thehoodiezandroid.views.adapters.ListViewCollectionAdapter;

import java.util.ArrayList;

public class MainActivity extends BaseActivity implements NavigationInterface {

    public static final int RESULT_OK = Activity.RESULT_OK;
    public static final int RESULT_CANCELLED = RESULT_CANCELED;
    private ListViewCollectionAdapter adapter;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base);

        mToolbar = findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);

        ActionBar ab = getSupportActionBar();

        if(ab != null) {
            ab.setDisplayShowTitleEnabled(false);
            ab.setDisplayShowCustomEnabled(true);
            ab.setDisplayHomeAsUpEnabled(false);
            ab.setDisplayShowHomeEnabled(false);
            ab.setTitle(DataManager.getInstance().getShopName());
        }

        initNavigation();

        recyclerView = findViewById(R.id.main_recycleview);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        adapter = new ListViewCollectionAdapter(this, mCollections);
        recyclerView.setAdapter(adapter);

        Button navigateToCategoryBtn = findViewById(R.id.navigateButton);
        navigateToCategoryBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NavigateToCategoriesActivity.class);
                startActivity(intent);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.search_menu, menu);
        MenuItem menuItem = menu.findItem(R.id.search);
        MenuItem cartBtn = menu.findItem(R.id.cartBtn);
        cartBtn.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                if(DataManagerHelper.getInstance().getCartProducts().size() == 0) {
                    MainActivity.this.showOnUiThread("Cart Is Empty");
                } else {
                    Intent navigate = new Intent(MainActivity.this, CartActivity.class);
                    startActivity(navigate);
                }
                return true;
            }
        });
        final SearchView sv = (SearchView) menuItem.getActionView();
        ImageView searchCloseIcon = sv.findViewById(android.support.v7.appcompat.R.id.search_close_btn);
        searchCloseIcon.setImageResource(R.drawable.ic_clear_black_24dp);
        sv.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                if(query.length() == 0) {
                    MainActivity.this.adapter.setData(DataManager.getInstance().getCollections());
                    menuItem.collapseActionView();
                } else {
                    MainActivity.this.adapter.setData(DataManager.getInstance().getCollectionsBySearchCriteria(query));
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                ArrayList<CollectionModel> lst = DataManager.getInstance().getCollectionsBySearchCriteria(newText);
                MainActivity.this.adapter.setData(lst);
                return true;
            }
        });
        return true;
    }


    @Override
    protected void initDrawer() {
        mDrawer = findViewById(R.id.drawer_layout);
        NavigationView optionsContainer = mDrawer.findViewById(R.id.drawer_options_container);

        updateUI();

        Menu menu = optionsContainer.getMenu();
        initMenuOptions(menu);
    }

    @Override
    public void navigateToProduct(String productId) {
        Intent intent = new Intent(MainActivity.this, ProductDetailsActivity.class);
        intent.putExtra("productId", productId);
        startActivity(intent);
        mDrawer.closeDrawer(Gravity.START);
    }

    @Override
    public void navigateToCollection(String collectionId) {
        DataManager.getInstance().products(collectionId, new BaseCallback() {
            @Override
            public void onResponse(int status) {
                if (status == BaseCallback.RESULT_OK) {
                    Intent intent = new Intent(MainActivity.this, CollectionActivity.class);
                    intent.putExtra("collectionId", collectionId);
                    startActivity(intent);
                } else {
                    onFailure("An unknown error occurred");
                }
            }

            @Override
            public void onFailure(String message) {
                MainActivity.this.showOnUiThread(message);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == BaseCallback.RESULT_OK) {
            // Registration was successful
            if (CurrentUser.getInstance().getId() == null) {
                String email = data.getStringExtra("userEmail");
                String pass = data.getStringExtra("userPass");
                DataManager.getInstance().login(
                        email,
                        pass,
                        new BaseCallback() {
                            @Override
                            public void onResponse(int status) {
                                MainActivity.this.updateUI();
                            }

                            @Override
                            public void onFailure(String message) {
                                showOnUiThread(message);
                            }
                        }
                );
            } else {
                MainActivity.this.updateUI();
            }
        } else if (resultCode == RESULT_CANCELLED) {
            //  Registration was cancelled by the user
            //do nothing
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    private void updateUI() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mDrawer == null) {
                    mDrawer = findViewById(R.id.drawer_layout);
                }

                NavigationView optionsContainer = mDrawer.findViewById(R.id.drawer_options_container);

                View headerContainer = optionsContainer.getHeaderView(0);
                TextView title = headerContainer.findViewById(R.id.sidemenu_logo_placeholder);
                title.setText(DataManager.getInstance().getShopName());
                TextView username = headerContainer.findViewById(R.id.sidemenu_username);
                TextView userEmail = headerContainer.findViewById(R.id.sidemenu_email);

                Button logOut = optionsContainer.findViewById(R.id.logOut);
                if (CurrentUser.getInstance().getId() != null) {
                    logOut.setVisibility(View.VISIBLE);
                    logOut.setOnClickListener(onClickListener -> {
                        CurrentUser.getInstance().logout();

                        Snackbar.make((View) mToolbar.getParent(), "You logged out", Snackbar.LENGTH_LONG)
                                .setAction("Close", listener -> {
                                }).show();
                        runOnUiThread(() -> {
                            MainActivity.this.updateUI();
                            MainActivity.this.rebuildDrawer();
                        });
                    });

                    username.setText(CurrentUser.getInstance().getDisplayName());
                    userEmail.setText(CurrentUser.getInstance().getEmail());
                } else {
                    logOut.setVisibility(View.GONE);
                    username.setText(R.string.login_user_text);
                    username.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (CurrentUser.getInstance().getId() == null) {
                                Intent login = new Intent(MainActivity.this, LoginActivity.class);
                                login.putExtra(LoginActivity.EVENT_SOURCE_KEY, true);
                                startActivityForResult(login, BaseCallback.RESULT_OK);
                            }
                            mDrawer.closeDrawer(Gravity.START);
                        }
                    });

                    userEmail.setText(R.string.create_user_text);
                    userEmail.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (CurrentUser.getInstance().getId() == null) {
                                Intent register = new Intent(MainActivity.this, RegisterActivity.class);
                                register.putExtra(LoginActivity.EVENT_SOURCE_KEY, true);
                                startActivityForResult(register, BaseCallback.RESULT_OK);
                            }
                            mDrawer.closeDrawer(Gravity.START);
                        }
                    });
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        rebuildDrawer();
    }
}
