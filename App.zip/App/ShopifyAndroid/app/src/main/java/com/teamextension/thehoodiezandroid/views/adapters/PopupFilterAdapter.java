/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.views.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.util.ArraySet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.model.ProductModel;
import com.teamextension.thehoodiezandroid.model.SelectedOptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class PopupFilterAdapter extends ArrayAdapter {
    private Context context;
    private ArrayList<ProductModel> prods;
    private HashMap<String, Set<String>> options;
    private ViewHolder holder;
    private SelectedOptions selectedOptions;

    public PopupFilterAdapter(@NonNull Context context, ArrayList<ProductModel> products, SelectedOptions selectedOptions) {
        super(context, 0);
        this.context = context;
        this.prods = products;
        this.selectedOptions = selectedOptions;
        options = new HashMap<String, Set<String>>();
        for (int i = 0; i < products.size(); i++) {

            for (ProductModel.ProductVariantModel prod : products.get(i).getVariants()) {
                for (Map.Entry<String, String> entry : prod.getSelectedOptions().entrySet()) {
                    if (options.containsKey(entry.getKey())) {
                        options.get(entry.getKey()).add(entry.getValue());
                    } else {
                        options.put(entry.getKey(), new ArraySet<String>());
                        options.get(entry.getKey()).add(entry.getValue());
                    }
                }
            }
        }
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if (convertView == null) {
            holder = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.popup_listitem_filter, parent, false);
            holder.selectedFilter = convertView.findViewById(R.id.selectedFilter);
            holder.filterName = convertView.findViewById(R.id.filterName);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Set<String> varNames = new ArraySet<>();

                for (Map.Entry<String, Set<String>> entry : options.entrySet()) {
                    varNames.add(entry.getKey());
                }



        int index = 0;
        String optionName = "";
        for (String s : varNames) {
            if (index == position) {
                optionName = s;
                break;
            } else {
                index++;
            }
        }


        for (int i = 0; i < varNames.size(); i++) {
            holder.filterName.setText(optionName);
        }

        switch (position){
            case 0:
                holder.selectedFilter.setText(selectedOptions.getSize());
                break;
            case 1:
                holder.selectedFilter.setText(selectedOptions.getColor());
                break;
            case 2:
                holder.selectedFilter.setText(selectedOptions.getMaterial());
                break;
            default:
                    holder.selectedFilter.setText("");
                    break;

        }
        return convertView;
    }

    @Override
    public int getCount() {
        return options != null ? options.size() : 0;
    }


    public static class ViewHolder {
        protected TextView selectedFilter;
        protected TextView filterName;

    }


}