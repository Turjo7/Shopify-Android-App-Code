/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.views;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.Scroller;

import com.shopify.buy3.Storefront;
import com.teamextension.thehoodiezandroid.activities.AbstractActivity;
import com.teamextension.thehoodiezandroid.fragments.AbstractCheckoutFragment;
import com.teamextension.thehoodiezandroid.fragments.AddressFragment;
import com.teamextension.thehoodiezandroid.fragments.PaymentFragment;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.managers.interfaces.BaseCallback;
import com.teamextension.thehoodiezandroid.managers.interfaces.NavigationToggleEvent;
import com.teamextension.thehoodiezandroid.managers.interfaces.OnNavigationOccurred;
import com.teamextension.thehoodiezandroid.model.CurrentUser;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

import static com.teamextension.thehoodiezandroid.fragments.AbstractCheckoutFragment.FRAGMENT_INDEX;

public class PaymentViewPager extends ViewPager implements OnNavigationOccurred, Observer {

    private static final String TAG = PaymentViewPager.class.getSimpleName();

    public static class PagerAdapter extends FragmentPagerAdapter {

        private ArrayList<Fragment> mFragments = new ArrayList<Fragment>();

        public PagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0: return "Customer Information";
                case 1: return "Billing";
                default: return "Payment";
            }
        }

        @Override
        public Fragment getItem(int position) {
            if(containsFragment(position)) {
                return mFragments.get(position);
            }

            AbstractCheckoutFragment f = null;
            Bundle args = new Bundle();
            switch (position) {
                case 0:
                    f = new AddressFragment();
                    args.putInt(FRAGMENT_INDEX, 0);
                    f.setArguments(args);
                    mFragments.add(f);
                    return f;
                case 1:
                    f = new AddressFragment();
                    args.putInt(FRAGMENT_INDEX, 1);
                    f.setArguments(args);
                    mFragments.add(f);
                    return f;
                case 2:
                    f = new PaymentFragment();
                    mFragments.add(f);
                    return f;

                default:
                    return null;
            }
        }

        @Override
        public int getCount() {
            return 3;
        }

        private boolean containsFragment(int position) {
            return position < mFragments.size() && position > -1;
        }
    }

    public interface OnPaymentOccurred {
        enum Status {
            SUCCESS, ERROR, COULD_NOT_BE_COMPLETED
        }

        class ResponseData<T> {
            public static final class ResponseCodes {
                public static final int STATUS_OK = 200;
                public static final int STATUS_FAIL = 201;
                public static final int STATUS_DISABLED = 202;
            }

            private T data = null;
            private int code = -1;
            private Status message = null;

            private ResponseData() {}

            public T data() {return this.data;}
            public int code() {return this.code;}
            public Status message() {return this.message;}

            private void data(@NonNull T data) {
                this.data = data;
            }

            private void code(int code) {
                this.code = code;
            }

            private void message(@NonNull Status status) {
                this.message = status;
            }
        }

        class Builder<T> {
            private ResponseData<T> data = new ResponseData<T>();
            public Builder<T> data(T data) {
                this.data.data(data);
                return this;
            }

            public Builder<T> code(int code) {
                this.data.code(code);
                return this;
            }

            public Builder<T> status(Status status) {
                this.data.message(status);
                return this;
            }

            public ResponseData<T> build() {
                return this.data;
            }
        }

        void onPaymentOccurred(ResponseData responseData);
    }

    private NavigationToggleEvent mNavigationListener = null;

    @Override
    public void setCurrentItem(int item) {
        super.setCurrentItem(item);
    }

    public PaymentViewPager(@NonNull Context context) {
        super(context);
        setScroller();
        if(context instanceof NavigationToggleEvent) {
            mNavigationListener = (NavigationToggleEvent) context;
        }
        DataManager.getInstance().addObserver(PaymentViewPager.this);
    }

    public PaymentViewPager(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        setScroller();
        if(context instanceof NavigationToggleEvent) {
            mNavigationListener = (NavigationToggleEvent) context;
        }
        DataManager.getInstance().addObserver(PaymentViewPager.this);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (this.IsSwipeAllowed(event)) {
            return super.onTouchEvent(event);
        }

        return false;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent event) {
        if (this.IsSwipeAllowed(event)) {
            return super.onInterceptTouchEvent(event);
        }

        return false;
    }

    @Override
    public void onNavigationOccurred(Direction direction) {
        switch (direction) {
            case CUSTOMER:
                setItem(0);
                break;
            case SHIPPING:
                setItem(1);
                break;
        }
    }

    public void validateFields() {
        android.support.v4.view.PagerAdapter adapter = getAdapter();

        if(adapter instanceof PagerAdapter) {
            final int index = getCurrentItem();
            if(index < 0 || index >= 2) {
                mNavigationListener.enableNavigation();
                return;
            }

            final AbstractCheckoutFragment f = (AbstractCheckoutFragment) ((PagerAdapter) adapter).getItem(index);

            boolean result = ((AbstractCheckoutFragment) f).validateFields();
            if(result) {
                switch (index) {
                    case 0:
                        updateCheckoutAddress();
                        break;

                    case 1:
                        updateBillingAddress();
                        break;

                    default:
                        Log.e(TAG, "Unknown action to be taken");
                }
            } else {
                mNavigationListener.enableNavigation();
            }
        }
    }

    private void setItem(final int pos) {
        ((Activity) getContext()).runOnUiThread(() -> {
            int index = PaymentViewPager.this.getCurrentItem();
            if(index != pos) {
                PaymentViewPager.this.setCurrentItem(pos);
                ((AbstractCheckoutFragment) ((PagerAdapter) PaymentViewPager.this.getAdapter()).getItem(pos)).setupData(DataManager.getInstance());
            }
        });
    }

    public void updateCheckoutAddress() {
        final int index = 0;
        final AbstractCheckoutFragment f = (AbstractCheckoutFragment) ((PagerAdapter) getAdapter()).getItem(index);
        final DataManager manager = DataManager.getInstance();
        if(f instanceof AddressFragment) {
            Storefront.MailingAddress address = ((AddressFragment) f).getAddress();
            if(manager.getCheckout() == null) {
                manager.createCheckout(new BaseCallback() {
                    @Override
                    public void onResponse(int status) {
                        manager.updateCheckoutAddress(manager.getCheckout().getId(), address, new BaseCallback() {
                            @Override
                            public void onResponse(int status) {
                                PaymentViewPager.this.setItem(1);
                                if(mNavigationListener != null) {
                                    mNavigationListener.enableNavigation();
                                }
                            }

                            @Override
                            public void onFailure(final String message) {
                                ((AbstractActivity) PaymentViewPager.this.getContext()).showOnUiThread(message);
                                PaymentViewPager.this.setItem(0);
                                Activity a = ((Activity) getContext());
                                if(a != null) {
                                    a.runOnUiThread(() -> {
                                        f.showErrors(message);
                                    });
                                }
                                if(mNavigationListener != null) {
                                    mNavigationListener.enableNavigation();
                                }
                            }
                        });
                    }

                    @Override
                    public void onFailure(String message) {
                        ((AbstractActivity) PaymentViewPager.this.getContext()).showOnUiThread(message);
                        PaymentViewPager.this.setItem(0);
                        Activity a = ((Activity) getContext());
                        if(a != null) {
                            a.runOnUiThread(() -> {
                                f.showErrors(message);
                            });
                        }
                        if(mNavigationListener != null) {
                            mNavigationListener.enableNavigation();
                        }
                    }
                });
            } else {
                if(CurrentUser.getInstance().getEmail().contentEquals(DataManager.getInstance().getCheckout().getEmail())) {
                    manager.updateCheckoutAddress(manager.getCheckout().getId(), address, new BaseCallback() {
                        @Override
                        public void onResponse(int status) {
                            PaymentViewPager.this.setItem(1);
                            if(mNavigationListener != null) {
                                mNavigationListener.enableNavigation();
                            }
                        }

                        @Override
                        public void onFailure(final String message) {
                            ((AbstractActivity) PaymentViewPager.this.getContext()).showOnUiThread(message);
                            PaymentViewPager.this.setItem(0);
                            Activity a = ((Activity) getContext());
                            if(a != null) {
                                a.runOnUiThread(() -> {
                                    f.showErrors(message);
                                });
                            }
                            if(mNavigationListener != null) {
                                mNavigationListener.enableNavigation();
                            }
                        }
                    });
                } else {
                    manager.updateCheckoutEmail(DataManager.getInstance().getCheckout().getId(), CurrentUser.getInstance().getEmail(), new BaseCallback() {
                        @Override
                        public void onResponse(int status) {
                            manager.updateCheckoutAddress(manager.getCheckout().getId(), address, new BaseCallback() {
                                @Override
                                public void onResponse(int status) {
                                    PaymentViewPager.this.setItem(1);
                                    if(mNavigationListener != null) {
                                        mNavigationListener.enableNavigation();
                                    }
                                }

                                @Override
                                public void onFailure(final String message) {
                                    ((AbstractActivity) PaymentViewPager.this.getContext()).showOnUiThread(message);
                                    PaymentViewPager.this.setItem(0);
                                    Activity a = ((Activity) getContext());
                                    if(a != null) {
                                        a.runOnUiThread(() -> {
                                            f.showErrors(message);
                                        });
                                    }
                                    if(mNavigationListener != null) {
                                        mNavigationListener.enableNavigation();
                                    }
                                }
                            });
                        }

                        @Override
                        public void onFailure(String message) {
                            ((AbstractActivity) PaymentViewPager.this.getContext()).showOnUiThread(message);
                            PaymentViewPager.this.setItem(0);
                            Activity a = ((Activity) getContext());
                            if(a != null) {
                                a.runOnUiThread(() -> {
                                    f.showErrors(message);
                                });
                            }
                            if(mNavigationListener != null) {
                                mNavigationListener.enableNavigation();
                            }
                        }
                    });
                }
            }
        }
    }

    public void updateBillingAddress() {
        DataManager manager = DataManager.getInstance();
        AbstractCheckoutFragment f = (AbstractCheckoutFragment) ((PagerAdapter) getAdapter()).getItem(1);
        if(f instanceof AddressFragment) {
            manager.updateBillingAddress(((AddressFragment) f).getAddress(), new BaseCallback() {
                @Override
                public void onResponse(int status) {
                    PaymentViewPager.this.setItem(2);
                    if(mNavigationListener != null) {
                        mNavigationListener.enableNavigation();
                    }
                }

                @Override
                public void onFailure(String message) {
                    ((AbstractActivity) PaymentViewPager.this.getContext()).showOnUiThread(message);
                    PaymentViewPager.this.setItem(1);
                    Activity a = ((Activity) getContext());
                    if(a != null) {
                        a.runOnUiThread(() -> {
                            f.showErrors(message);
                        });
                    }
                    if(mNavigationListener != null) {
                        mNavigationListener.enableNavigation();
                    }
                }
            });
        }
    }

    public void pay() {
        int currentItem = this.getCurrentItem();
        if(currentItem == 2) {
            PaymentFragment f = (PaymentFragment) ((PagerAdapter) getAdapter()).getItem(currentItem);
            f.placeOrder((OnPaymentOccurred) getContext());
        } else {
            if(mNavigationListener != null) {
                mNavigationListener.enableNavigation();
            }
        }
    }

    private float startX;

    private boolean IsSwipeAllowed(final MotionEvent event) {
        final int actionMasked = event.getActionMasked() & MotionEvent.ACTION_MASK;
        switch (actionMasked) {
            case MotionEvent.ACTION_DOWN:
                startX = event.getX();
                return true;

                case MotionEvent.ACTION_MOVE:
                    if(event.getX() - startX < 0) {
                        validateFields();
                        return false;
                    }

                    startX = event.getX();
                    return true;

            default:
                return true;
        }
    }

    private void setScroller() {
        try {
            Class<?> viewPager = ViewPager.class;
            Field scroller = viewPager.getDeclaredField("mScroller");
            scroller.setAccessible(true);
            scroller.set(this, new CustomScroller(getContext()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(Observable o, Object arg) {
        if(o instanceof DataManager) {
            AbstractCheckoutFragment f = (AbstractCheckoutFragment) ((PagerAdapter) getAdapter()).getItem(getCurrentItem());
            f.setupData((DataManager) o);
        }
    }


}

class CustomScroller extends Scroller {
    CustomScroller(Context context) {
        super(context);
    }

    @Override
    public void startScroll(int startX, int startY, int dx, int dy, int duration) {
        super.startScroll(startX, startY, dx, dy, 350);
    }
}