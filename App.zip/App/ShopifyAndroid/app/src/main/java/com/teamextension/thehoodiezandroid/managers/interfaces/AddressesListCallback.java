/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.managers.interfaces;

import com.shopify.graphql.support.ID;

public interface AddressesListCallback {
    void updateDefault(String message, boolean update);
    void updateNav(String addressId);
}
