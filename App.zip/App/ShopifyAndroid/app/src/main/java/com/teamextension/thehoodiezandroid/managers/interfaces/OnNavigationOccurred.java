/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.managers.interfaces;

public interface OnNavigationOccurred {
    enum Direction {
        CUSTOMER, SHIPPING
    }

    void onNavigationOccurred(Direction direction);
}
