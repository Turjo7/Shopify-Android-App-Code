/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.fragments;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Paint;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.shopify.graphql.support.ID;
import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.activities.AbstractActivity;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.managers.DataManagerHelper;
import com.teamextension.thehoodiezandroid.model.ProductModel;
import com.teamextension.thehoodiezandroid.views.adapters.ViewPagerAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class ProductFragment extends Fragment {

    private static final String SHOP_CURRENCY = DataManager.getInstance().getShopCurrency();

    private ViewPager pager;
    private LinearLayout sliderDots;
    private LinearLayout containerList;
    private int dotsCount;
    private ImageView[] dots;
    private Boolean sortBySize = false;
    private Boolean sortByMaterial = false;
    private ImageView addToCart;
    private TextView productTitle;
    private TextView oldPrice;
    private TextView newPrice;
    private TextView salesLabel;
    private ProductModel product;
    private String productId = "";
    private Activity parent = null;
    private ArrayList<ProductModel.ProductVariantModel> productVariants;
    private ProductModel.ProductVariantModel selectedVariant;
    private HashMap<String, String> selectedOptions;
    private ID variantModelID;

    public static final float NEW_PRICE_TEXT_SIZE = 18;
    public static final float OLD_PRICE_TEXT_SIZE = 14;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View productFragment = inflater.inflate(R.layout.fragment_product,container, false);
        pager = productFragment.findViewById(R.id.viewPager);
        sliderDots = productFragment.findViewById(R.id.sliderDots);
        containerList = productFragment.findViewById(R.id.prodDetailsActivityListView);
        productTitle = productFragment.findViewById(R.id.productTitle);
        oldPrice = productFragment.findViewById(R.id.oldPrice);
        newPrice = productFragment.findViewById(R.id.newPrice);
        addToCart = productFragment.findViewById(R.id.floatingCartBtn);
        salesLabel = productFragment.findViewById(R.id.label);

        if(productId.length() == 0){
            parent.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getContext(),"An error occurred", Toast.LENGTH_SHORT).show();
                }
            });
            return productFragment;
        }
        product = DataManager.getInstance().getProductByID(productId);

        if(product == null) {
            parent.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getContext(), "Product is null", Toast.LENGTH_LONG).show();
                }
            });
            return productFragment;
        }

        createProductVariants();
        addOptions();

        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getContext(), product);
        pager.setAdapter(viewPagerAdapter);

        dotsCount = viewPagerAdapter.getCount();
        dots = new ImageView[dotsCount];

        for(int i = 0; i < dotsCount; i++){
            dots[i] = new ImageView(getContext());
            dots[i].setImageDrawable(ContextCompat.getDrawable(Objects.requireNonNull(getContext()), R.drawable.ic_inactive_dot_black_24dp));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(8,0,8,0);
            sliderDots.addView(dots[i], params);
        }
        dots[0].setImageDrawable(ContextCompat.getDrawable(Objects.requireNonNull(getContext()), R.drawable.ic_active_dot_black_24dp));

        pager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                for(int i = 0; i < dotsCount; i++){
                    dots[i].setImageDrawable(ContextCompat.getDrawable(getContext(), R.drawable.ic_inactive_dot_black_24dp));
                }
                dots[position].setImageDrawable(ContextCompat.getDrawable(getContext(), R.drawable.ic_active_dot_black_24dp));
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        addToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.setFocusable(false);
                v.setClickable(false);

                if(selectedVariant != null && selectedVariant.isAvailableForSale() &&
                        selectedVariant.getOldPrice() != null &&
                        selectedVariant.getOldPrice().compareTo(selectedVariant.getPrice()) > 0) {
                    DataManagerHelper.getInstance().addToCart(variantModelID);
                    Toast.makeText(getContext(), "Product added to cart", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getContext(), "Product out of stock", Toast.LENGTH_LONG).show();
                }
                v.setFocusable(true);
                v.setClickable(true);
            }
        });

        productTitle.setText(product.getTitle());

        if(this.product.getVariants().get(0).getOldPrice() != null &&
                this.product.getVariants().get(0).getOldPrice().compareTo(this.product.getVariants().get(0).getPrice()) > 0 &&
                this.product.getVariants().get(0).isAvailableForSale()) {
            this.oldPrice.setText(this.product.getVariants().get(0).getOldPrice().toString() + ' ' +
                    SHOP_CURRENCY);
            this.oldPrice.setPaintFlags(this.oldPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            this.newPrice.setVisibility(View.VISIBLE);
            this.newPrice.setText(this.product.getVariants().get(0).getPrice().toString() + ' ' +
                    SHOP_CURRENCY);
            this.oldPrice.setTextSize(TypedValue.COMPLEX_UNIT_SP, OLD_PRICE_TEXT_SIZE);
        }  else {
            this.newPrice.setVisibility(View.INVISIBLE);
            this.oldPrice.setVisibility(View.VISIBLE);
            this.oldPrice.setTextSize(TypedValue.COMPLEX_UNIT_SP, NEW_PRICE_TEXT_SIZE);
            this.oldPrice.setText(this.product.getVariants().get(0).getPrice().toString() + ' ' +
                    SHOP_CURRENCY);
        }


       return productFragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        assert getArguments() != null;
        productId = getArguments().getString("productId");
            if (context instanceof AbstractActivity) {
                parent = (AbstractActivity) context;
           }
    }

    public void createProductVariants(){
        productVariants = product.getVariants();
    }

    public void addOptions(){
        ProductModel.ProductVariantModel variant = productVariants.get(0);
        selectedVariant = variant;
        variantModelID = variant.getID();
        HashMap<String, String> variantOptions = variant.getSelectedOptions();
        selectedOptions = variantOptions;

        for(Map.Entry<String,String> key : variantOptions.entrySet()) {

            LayoutInflater inflater = (LayoutInflater) Objects.requireNonNull(getContext()).getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            assert inflater != null;
            View view= inflater.inflate(R.layout.option_item_layout,null);

            OptionItemHolder holder = new OptionItemHolder();
            holder.optionName = view.findViewById(R.id.optionName);
            holder.optionSelected = view.findViewById(R.id.optionSelected);
            holder.changeOption = view.findViewById(R.id.changeOption);
            view.setTag(key.getKey());

            holder.optionName.setText(key.getKey());
            holder.optionSelected.setText(key.getValue());
            holder.changeOption.setText(R.string.change_text);

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                        showDialogOption(key.getKey());
                }
            });

            containerList.addView(view);
        }
    }

    public void showDialogOption(String optionName) {
        final Dialog dialog = new Dialog(Objects.requireNonNull(getContext()));

        DisplayMetrics dm = getContext().getResources().getDisplayMetrics();
        final int height = (int) (dm.heightPixels * 0.5);
        final int width = (int) (dm.widthPixels * 0.8);

//        dialog.getWindow().setLayout(width, height);

        ArrayList<ProductModel.ProductVariantModel> productAvailableVariants =  new ArrayList<>();
        ArrayList<String> options = new ArrayList<>();

        switch (optionName) {
            case "Size": {
                sortBySize = true;

                dialog.setContentView(R.layout.popup_size_filter);
                Objects.requireNonNull(dialog.getWindow()).setLayout(width, height);
                ImageView backArrow = dialog.findViewById(R.id.backArrow);
                backArrow.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                for (ProductModel.ProductVariantModel variant : productVariants) {
                    HashMap<String, String> variantOptions = variant.getSelectedOptions();

                    if (sortByMaterial) {
                        String material = selectedOptions.get("Material");

                        if (variantOptions.get("Material").equals(material)) {
                            productAvailableVariants.add(variant);

                            if (!options.contains(variantOptions.get(optionName))) {
                                options.add(variantOptions.get(optionName));
                            }
                        }
                    } else {
                        productAvailableVariants.add(variant);

                        if (!options.contains(variantOptions.get(optionName))) {
                            options.add(variantOptions.get(optionName));
                        }
                    }
                }

                LinearLayout optionsList = dialog.findViewById(R.id.rgLayout);
                createOptionsPopUpList(optionName, optionsList, options, productAvailableVariants, dialog);

                dialog.show();
                break;
            }
            case "Color": {

                dialog.setContentView(R.layout.popup_color_filter);
                Objects.requireNonNull(dialog.getWindow()).setLayout(width, height);
                ImageView backArrow = dialog.findViewById(R.id.backArrow3);
                backArrow.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                for (ProductModel.ProductVariantModel variant : productVariants) {
                    HashMap<String, String> variantOptions = variant.getSelectedOptions();

                    if (sortBySize && !sortByMaterial) {
                        String size = selectedOptions.get("Size");

                        if (variantOptions.get("Size").equals(size)) {
                            productAvailableVariants.add(variant);

                            if (!options.contains(variantOptions.get(optionName))) {
                                options.add(variantOptions.get(optionName));
                            }
                        }
                    } else if (!sortBySize && sortByMaterial) {
                        String material = selectedOptions.get("Material");

                        if (variantOptions.get("Material").equals(material)) {
                            productAvailableVariants.add(variant);

                            if (!options.contains(variantOptions.get(optionName))) {
                                options.add(variantOptions.get(optionName));
                            }
                        }
                    } else if (sortBySize && sortByMaterial) {
                        String size = selectedOptions.get("Size");
                        String material = selectedOptions.get("Material");

                        if (variantOptions.get("Size").equals(size) && variantOptions.get("Material").equals(material)) {
                            productAvailableVariants.add(variant);

                            if (!options.contains(variantOptions.get(optionName))) {
                                options.add(variantOptions.get(optionName));
                            }
                        }
                    } else {

                        productAvailableVariants.add(variant);
                        if (!options.contains(variantOptions.get(optionName))) {
                            options.add(variantOptions.get(optionName));
                        }
                    }
                }

                LinearLayout optionsList = dialog.findViewById(R.id.radioLayout);
                createOptionsPopUpList(optionName, optionsList, options, productAvailableVariants, dialog);

                dialog.show();
                break;
            }
            case "Material": {
                sortByMaterial = true;

                dialog.setContentView(R.layout.popup_material_filter);
                Objects.requireNonNull(dialog.getWindow()).setLayout(width, height);
                ImageView backArrow = dialog.findViewById(R.id.backArrow4);
                backArrow.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                for (ProductModel.ProductVariantModel variant : productVariants) {
                    HashMap<String, String> variantOptions = variant.getSelectedOptions();
                    productAvailableVariants.add(variant);

                    if (!options.contains(variantOptions.get(optionName))) {
                        options.add(variantOptions.get(optionName));
                    }
                }

                LinearLayout optionsList = dialog.findViewById(R.id.radLayout);
                createOptionsPopUpList(optionName, optionsList, options, productAvailableVariants, dialog);

                dialog.show();
                break;
            }
        }

        dialog.show();
    }

    public void createOptionsPopUpList(String optionName, LinearLayout optionsList, ArrayList<String> options, ArrayList<ProductModel.ProductVariantModel> productAvailableVariants, Dialog dialog){
        RadioGroup rg = new RadioGroup(getContext());
        rg.setOrientation(RadioGroup.VERTICAL);
        RadioGroup.LayoutParams rl;

        for (int i = 0; i < options.size(); i++) {
            RadioButton rb = new RadioButton(getContext());
            List lst = new ArrayList<>(options);
            rb.setText(lst.get(i).toString());
            rb.setTextColor(getResources().getColor(R.color.primary_color_dark, null));

            rb.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    for(ProductModel.ProductVariantModel variant : productAvailableVariants) {
                        HashMap<String,String> variantOptions = variant.getSelectedOptions();

                        if(variantOptions.get(optionName).equals(rb.getText())){
                            selectedVariant = variant;
                            variantModelID = variant.getID();
                            selectedOptions = variantOptions;

                            for(Map.Entry<String,String> key : variantOptions.entrySet()) {

                                View view = containerList.findViewWithTag(key.getKey());

                                OptionItemHolder holder = new OptionItemHolder();
                                holder.optionName = view.findViewById(R.id.optionName);
                                holder.optionSelected = view.findViewById(R.id.optionSelected);
                                holder.changeOption = view.findViewById(R.id.changeOption);
                                view.setTag(key.getKey());

                                holder.optionName.setText(key.getKey());
                                holder.optionSelected.setText(key.getValue());
                                holder.changeOption.setText(R.string.change_text);
                            }
                            break;
                        }
                    }

                    dialog.dismiss();
                }
            });

            ColorStateList colorStateList = new ColorStateList(
                    new int[][]{
                            new int[]{-android.R.attr.state_enabled}, //disabled
                            new int[]{android.R.attr.state_enabled} //enabled
                    },
                    new int[]{
                            getResources().getColor(R.color.tertiary_color_dark, null) //disabled
                            , getResources().getColor(R.color.primary_color_dark,null) //enabled
                    }
            );

            rb.setButtonTintList(colorStateList);
            rl = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.MATCH_PARENT, RadioGroup.LayoutParams.MATCH_PARENT);
            rg.addView(rb, rl);
        }
        optionsList.addView(rg);
    }
}

class OptionItemHolder {
    public TextView optionName;
    public TextView optionSelected;
    public TextView changeOption;
}
