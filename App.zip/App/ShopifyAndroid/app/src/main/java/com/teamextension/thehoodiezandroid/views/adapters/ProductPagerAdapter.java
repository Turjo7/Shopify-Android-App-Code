/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.views.adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;


public class ProductPagerAdapter extends FragmentPagerAdapter {
    public interface OnFragmentChangedToggleFloatingActionButton {
        void onFragmentChanged(Fragment fragment);
    }

    private List<Fragment> fragments = new ArrayList<>();
    private List<String> tabNames = new ArrayList<>();
    private OnFragmentChangedToggleFloatingActionButton mCallback = null;

    public ProductPagerAdapter(FragmentManager fm, OnFragmentChangedToggleFloatingActionButton onFragmentChangedToggleFloatingActionButton) {
        super(fm);
        mCallback = onFragmentChangedToggleFloatingActionButton;
    }
    public void addFragment(Fragment fragment, String title){
        fragments.add(fragment);
        tabNames.add(title);
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return fragments.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return tabNames.get(position);
    }

}
