/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.views.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.activities.MainActivity;
import com.teamextension.thehoodiezandroid.managers.interfaces.NavigationInterface;
import com.teamextension.thehoodiezandroid.model.CollectionModel;

import java.util.ArrayList;


public class ListViewCollectionAdapter extends RecyclerView.Adapter<ListViewCollectionAdapter.ItemRowHolder>  {
    private ArrayList<CollectionModel> dataList;
    private Context mContext;
    private NavigationInterface mCallback = null;

    public ListViewCollectionAdapter(Context context, ArrayList<CollectionModel> dataList) {
        this.dataList = dataList;
        this.mContext = context;
        if(context instanceof MainActivity){
            mCallback = (NavigationInterface) context;
        }
    }

    @NonNull
    @Override
    public ItemRowHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.listview_collection, null);

        return new ItemRowHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ListViewCollectionAdapter.ItemRowHolder holder, int position) {

        CollectionModel collection = dataList.get(position);
        holder.bind(collection, position, mCallback);

        if(collection.getPreviewProducts().size() == 0) {
            holder.hideView();
        } else {
            holder.showView();
        }
    }

    @Override
    public int getItemCount() {
        return (null != dataList ? dataList.size() : 0);
    }

    public void setData(ArrayList<CollectionModel> data) {
        this.dataList = data;
        this.notifyDataSetChanged();
    }

    class ItemRowHolder extends RecyclerView.ViewHolder {

        private TextView itemTitle;
        private RecyclerView recycler_view_list;
        private Button viewAllProducts;

        ItemRowHolder(View view) {
            super(view);

            this.itemTitle = view.findViewById(R.id.itemTitle);
            this.recycler_view_list = view.findViewById(R.id.recycler_view_list);
            this.viewAllProducts= view.findViewById(R.id.viewAllProducts);
        }
        void bind(final CollectionModel singleItem, int position, NavigationInterface callback){
            final String sectionName = singleItem.getTitle();
            this.itemTitle.setText(sectionName);

            ListViewCollectionItemAdapter adapter = new ListViewCollectionItemAdapter(mContext, singleItem.getPreviewProducts());
            this.recycler_view_list.setHasFixedSize(true);
            this.recycler_view_list.setLayoutManager(new LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL, false));
            this.recycler_view_list.setAdapter(adapter);

            this.viewAllProducts.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    callback.navigateToCollection(singleItem.getID().toString());
                }
            });

        }

        void hideView() {
            ((View) this.itemTitle.getParent().getParent()).setVisibility(View.GONE);
        }

        void showView() {
            ((View) this.itemTitle.getParent().getParent()).setVisibility(View.VISIBLE);
            this.itemTitle.setVisibility(View.VISIBLE);
            this.recycler_view_list.setVisibility(View.VISIBLE);
            this.viewAllProducts.setVisibility(View.VISIBLE);
        }
    }
}

