/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.shopify.buy3.Storefront;
import com.shopify.graphql.support.ID;
import com.teamextension.thehoodiezandroid.CommonUtils;
import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.managers.interfaces.BaseCallback;
import com.teamextension.thehoodiezandroid.managers.interfaces.NavigationToggleEvent;
import com.teamextension.thehoodiezandroid.model.CurrentUser;

public class AddressUpdateActivity extends AbstractActivity implements View.OnClickListener, BaseCallback, NavigationToggleEvent {

    public static final String ADDRESS_ID_KEY = "address_id";

    private String mAddressId;
    private Storefront.MailingAddress mAddressData;

    private AppCompatEditText mFirstName;
    private AppCompatEditText mLastName;
    private AppCompatEditText mAddress1;
    private AppCompatEditText mAddress2;
    private AppCompatEditText mZip;
    private AppCompatEditText mCity;
    private AppCompatEditText mCountry;
    private AppCompatEditText mPhone;
    private AppCompatEditText mCompany;
    private AppCompatEditText mProvince;

    private Button mSaveAddress;
    private Button mCancel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_address);

        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView title = toolbar.findViewById(R.id.title);
        title.setText("");

        ImageView backButton = toolbar.findViewById(R.id.backButton);
        backButton.setVisibility(View.VISIBLE);
        backButton.setOnClickListener(this);

        mFirstName = findViewById(R.id.account_details_firstName_value);
        mLastName = findViewById(R.id.account_details_lastName_value);
        mAddress1 = findViewById(R.id.account_details_address_1_value);
        mAddress2 = findViewById(R.id.account_details_address_2_value);
        mZip = findViewById(R.id.account_details_zip_value);
        mCity = findViewById(R.id.account_details_city_value);
        mCountry = findViewById(R.id.account_details_country_value);
        mPhone = findViewById(R.id.account_details_phone_value);
        mCompany = findViewById(R.id.account_details_company_value);
        mProvince = findViewById(R.id.account_details_province_value);

        mSaveAddress = findViewById(R.id.account_details_save_button);
        mCancel = findViewById(R.id.account_details_cancel_button);

        mSaveAddress.setOnClickListener(this);
        mCancel.setOnClickListener(this);

        mAddressId = getIntent().getStringExtra(ADDRESS_ID_KEY);
        mAddressData = (mAddressId == null || mAddressId.isEmpty()) ? null : CurrentUser.getInstance().getAddress(new ID(mAddressId));

        if(mAddressData != null) {
            mSaveAddress.setText(R.string.save_text);
            mFirstName.setText(mAddressData.getFirstName());
            mLastName.setText(mAddressData.getLastName());
            mAddress1.setText(mAddressData.getAddress1());
            mAddress2.setText(mAddressData.getAddress2());
            mZip.setText(mAddressData.getZip());
            mCity.setText(mAddressData.getCity());
            mCountry.setText(mAddressData.getCountry());
            mPhone.setText(mAddressData.getPhone());
            mCompany.setText(mAddressData.getCompany());
            mProvince.setText(mAddressData.getProvince());
        }
    }

    @Override
    public void onClick(View view) {
        AddressUpdateActivity.this.runOnUiThread(AddressUpdateActivity.this::disableNavigation);
        switch (view.getId()) {
            case R.id.account_details_save_button:
                AddressUpdateActivity.this.checkFields();
                break;

            // Cancel or Back button has been pressed
            case R.id.account_details_cancel_button:
            default:
                AddressUpdateActivity.this.runOnUiThread(() -> {
                        AddressUpdateActivity.this.setResult(RESULT_CANCELED);
                        AddressUpdateActivity.this.finish();
                });
        }
    }

    private void checkFields() {
        boolean isValid = true;

        String MANDATORY_FIELD_ERROR_MESSAGE = AddressUpdateActivity.this.getResources().getString(R.string.empty_field_error_message);
        String INVALID_FIELD_VALUE = "Invalid %s";
        String EXT_INVALID_FIELD_VALUE = String.format(INVALID_FIELD_VALUE, "value. %s cannot contain %s");

        String firstName = mFirstName.getText().toString();
        if(firstName.isEmpty() || !CommonUtils.isNameValid(firstName)) {
            if(firstName.isEmpty()) {
                mFirstName.setError(MANDATORY_FIELD_ERROR_MESSAGE);
            } else {
                mFirstName.setError(String.format(INVALID_FIELD_VALUE, "first name"));
            }
            isValid = false;
        }

        String lastName = mLastName.getText().toString();
        if(lastName.isEmpty() || !CommonUtils.isNameValid(lastName)) {
            if(lastName.isEmpty()) {
                mLastName.setError(MANDATORY_FIELD_ERROR_MESSAGE);
            } else {
                mLastName.setError(String.format(INVALID_FIELD_VALUE, "last name"));
            }
            isValid = false;
        }

        String address1 = mAddress1.getText().toString();
        if(address1.isEmpty() || !CommonUtils.isAlphaNumeric(address1)) {
            if(address1.isEmpty()) {
                mAddress1.setError(MANDATORY_FIELD_ERROR_MESSAGE);
            } else {
                mAddress1.setError(String.format(EXT_INVALID_FIELD_VALUE, "Address", "special characters"));
            }
            isValid = false;
        }

        String zip = mZip.getText().toString();
        if(zip.isEmpty() || !CommonUtils.isNumeric(zip)) {
            if(zip.isEmpty()) {
                mZip.setError(MANDATORY_FIELD_ERROR_MESSAGE);
            } else {
                mZip.setError(String.format(EXT_INVALID_FIELD_VALUE, "Zip Code", "special characters"));
            }
            isValid = false;
        }

        String country = mCountry.getText().toString();
        if(country.isEmpty() || !CommonUtils.isNameValid(country)) {
            if(country.isEmpty()) {
                mCountry.setError(MANDATORY_FIELD_ERROR_MESSAGE);
            } else {
                mCountry.setError(String.format(EXT_INVALID_FIELD_VALUE, "Country", "special characters or numbers"));
            }
            isValid = false;
        }

        String city = mCity.getText().toString();
        if(city.isEmpty() || !CommonUtils.isNameValid(city)) {
            if(city.isEmpty()) {
                mCity.setError(MANDATORY_FIELD_ERROR_MESSAGE);
            } else {
                mCity.setError(String.format(EXT_INVALID_FIELD_VALUE, "City", "special characters or numbers"));
            }
            isValid = false;
        }

        String province = mProvince.getText().toString();
        if(province.isEmpty() || !CommonUtils.isNameValid(province)) {
            if(province.isEmpty()) {
                mProvince.setError(MANDATORY_FIELD_ERROR_MESSAGE);
            } else {
                mProvince.setError(String.format(EXT_INVALID_FIELD_VALUE, "Province", "special characters or numbers"));
            }
        }

        String phone = mPhone.getText().toString();
        String company = mCompany.getText().toString();
        String address2 = mAddress2.getText().toString();
        if(isValid) {
            AddressUpdateActivity.this.sendRequest(
                    firstName, lastName, phone, company, address1,
                    address2, zip, city, province, country
            );
        } else {
            AddressUpdateActivity.this.runOnUiThread(AddressUpdateActivity.this::enableNavigation);
        }
    }

    private void showErrors(String msg) {
        if(msg.toLowerCase().contains("first")) {
            mFirstName.setError(msg);
            return;
        }

        if(msg.toLowerCase().contains("last")) {
            mLastName.setError(msg);
            return;
        }

        if(msg.toLowerCase().contains("address 1")) {
            mAddress1.setError(msg);
            return;
        }

        if(msg.toLowerCase().contains("address 2")) {
            mAddress2.setError(msg);
            return;
        }

        if(msg.toLowerCase().contains("zip") || msg.toLowerCase().contains("postal")) {
            mZip.setError(msg);
            return;
        }

        if(msg.toLowerCase().contains("city")) {
            mCity.setError(msg);
            return;
        }

        if(msg.toLowerCase().contains("country")) {
            mCountry.setError(msg);
            return;
        }

        if(msg.toLowerCase().contains("province")) {
            mProvince.setError(msg);
            return;
        }

        AddressUpdateActivity.this.showOnUiThread(msg);
    }

    private void sendRequest(String firstName, String lastName, String phone, String company, String address1, String address2, String zip, String city, String province, String country) {
        if(mAddressData != null) {
            DataManager.getInstance().updateUserDetails(
                    mAddressId,
                    firstName, lastName, phone, company, address1, address2, zip, city, province, country,
                    ID.equals(
                            CurrentUser.getInstance().getAddress().getId(),
                            mAddressData.getId()
                    ),
                    this
            );
        } else {
            DataManager.getInstance().createUserAddress(
                    firstName, lastName, phone, company, address1, address2, zip, city, province, country,
                    CurrentUser.getInstance().getAddress() == null,
                    this
            );
        }
    }

    @Override
    public void onResponse(int status) {
        Intent result = getIntent();
        result.putExtra(ADDRESS_ID_KEY, mAddressId);
        AddressUpdateActivity.this.setResult(AccountActivity.RESULT_UPDATE, result);
        AddressUpdateActivity.this.finish();
    }

    @Override
    public void onFailure(final String message) {
        AddressUpdateActivity.this.runOnUiThread(() -> {
            AddressUpdateActivity.this.showErrors(message);
            AddressUpdateActivity.this.enableNavigation();
        });
    }

    @Override
    public void enableNavigation() {
        mSaveAddress.setClickable(true);
        mSaveAddress.setFocusable(true);
        mCancel.setClickable(true);
        mCancel.setFocusable(true);
    }

    @Override
    public void disableNavigation() {
        mSaveAddress.setClickable(false);
        mSaveAddress.setFocusable(false);
        mCancel.setClickable(false);
        mCancel.setFocusable(false);
    }
}
