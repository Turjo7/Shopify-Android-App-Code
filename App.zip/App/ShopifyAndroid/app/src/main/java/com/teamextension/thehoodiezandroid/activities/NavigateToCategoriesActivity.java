/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.managers.DataManagerHelper;
import com.teamextension.thehoodiezandroid.managers.interfaces.BaseCallback;
import com.teamextension.thehoodiezandroid.managers.interfaces.NavigationInterface;
import com.teamextension.thehoodiezandroid.model.CollectionModel;
import com.teamextension.thehoodiezandroid.views.adapters.NavigateToCategoryAdapter;

import java.util.ArrayList;

public class NavigateToCategoriesActivity extends AbstractActivity implements NavigationInterface {
    private ArrayList<CollectionModel> mCollections = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigate_to_categories);

        mCollections = DataManager.getInstance().getCollections();

        //region Toolbar setup
        Toolbar toolbar = findViewById(R.id.toolbar);

        ImageButton backButton = toolbar.findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        TextView title = toolbar.findViewById(R.id.title);
        title.setText(R.string.categories_title);

        ImageView cartBtn = toolbar.findViewById(R.id.cart);
        cartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(DataManagerHelper.getInstance().getCartProducts().size() == 0) {
                    NavigateToCategoriesActivity.this.showOnUiThread("Cart Is Empty");
                } else {
                    Intent navigate = new Intent(NavigateToCategoriesActivity.this, CartActivity.class);
                    startActivity(navigate);
                }
            }
        });
        //endregion

        ListView categoryListView = findViewById(R.id.categoriesListView);
        NavigateToCategoryAdapter navAdapter = new NavigateToCategoryAdapter(this, mCollections);
        categoryListView.setAdapter(navAdapter);
    }

    @Override
    public void navigateToProduct(String productId) {
        //doNothing
    }

    @Override
    public void navigateToCollection(String collectionId) {
        DataManager.getInstance().products(collectionId, new BaseCallback() {
            @Override
            public void onResponse(int status) {
                if (status == RESULT_OK) {
                    Intent intent = new Intent(NavigateToCategoriesActivity.this, CollectionActivity.class);
                    intent.putExtra("collectionId", collectionId);
                    NavigateToCategoriesActivity.this.startActivity(intent);
                } else {
                    onFailure("An unknown error occurred");
                }
            }

            @Override
            public void onFailure(String message) {
                NavigateToCategoriesActivity.this.showOnUiThread(message);
            }
        });
    }
}
