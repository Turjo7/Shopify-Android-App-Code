/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.widget.EditText;

import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.managers.interfaces.OnNavigationOccurred;
import com.teamextension.thehoodiezandroid.views.PaymentViewPager;

public abstract class AbstractCheckoutFragment extends Fragment {
    public static final String FRAGMENT_INDEX = "FRAGMENT_INDEX";
    protected OnNavigationOccurred onNavigationOccurred = null;
    protected int fragmentIndex = -1;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        if(context instanceof OnNavigationOccurred) {
            this.onNavigationOccurred = (OnNavigationOccurred) context;
        }

        Bundle args = getArguments();
        if(args != null) {
            this.fragmentIndex = args.getInt(FRAGMENT_INDEX);
        }
    }

    public abstract boolean validateFields();

    public abstract void setupData(DataManager manager);

    public abstract void showErrors(String error);

    protected String getText(EditText view) {
        return view != null && view.getText() != null ? view.getText().toString() : "";
    }
}
