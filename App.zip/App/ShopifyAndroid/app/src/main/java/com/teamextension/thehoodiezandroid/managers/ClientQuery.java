/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.managers;

import com.shopify.buy3.Storefront;
import com.shopify.graphql.support.ID;

final class ClientQuery {

    static Storefront.QueryRootQuery queryForShop() {
        return Storefront.query(
                rootQuery -> rootQuery
                        .shop(
                                shopQuery -> shopQuery
                                        .name()
                                        .description()
                                        .paymentSettings(
                                                payment -> payment
                                                .countryCode()
                                                .currencyCode()
                                                .acceptedCardBrands()
                                        )
                                        .privacyPolicy(
                                                privacyQuery -> privacyQuery
                                                        .url()
                                        )
                                        .termsOfService(
                                                termsQuery -> termsQuery
                                                        .url()
                                        )

                        )
        );
    }

    static Storefront.QueryRootQuery queryShopShippingRates() {
        return Storefront.query(
                root -> root
                .shop(
                        shop -> shop
                        .paymentSettings(
                                payment -> payment
                                .acceptedCardBrands()
                                .countryCode()
                                .currencyCode()
                        )
                )
        );
    }

    static Storefront.QueryRootQuery queryCollections() {
        return Storefront.query(
                rootQuery -> rootQuery
                        .shop(
                                shopQuery -> shopQuery
                                        .collections(
                                                arg -> arg.first(50),
                                                collectionsQuery -> collectionsQuery
                                                        .pageInfo(
                                                                colPageQuery -> colPageQuery
                                                                        .hasNextPage()
                                                        )
                                                        .edges(
                                                                colEdgeQuery -> colEdgeQuery
                                                                        .node(
                                                                                colNodeQuery -> colNodeQuery
                                                                                        .handle()
                                                                                        .title()
                                                                                        .updatedAt()
                                                                                        .products(
                                                                                                args -> args.first(250),
                                                                                                prodQuery -> prodQuery
                                                                                                        .edges(
                                                                                                                prodEdge -> prodEdge
                                                                                                                        .node(
                                                                                                                                prodEdgeQuery -> prodEdgeQuery
                                                                                                                                        .images(
                                                                                                                                                args -> args.first(100),
                                                                                                                                                productImgQuery -> productImgQuery
                                                                                                                                                        .edges(
                                                                                                                                                                pieq -> pieq
                                                                                                                                                                        .node(
                                                                                                                                                                                pienq -> pienq
                                                                                                                                                                                        .src()
                                                                                                                                                                        )
                                                                                                                                                        )
                                                                                                                                        )
                                                                                                                                        .title()
                                                                                                                                        .descriptionHtml()
                                                                                                                                        .publishedAt()
                                                                                                                                        .updatedAt()
                                                                                                                                        .tags()
                                                                                                                                        .variants(
                                                                                                                                                args -> args.first(250),
                                                                                                                                                productVariantQuery -> productVariantQuery
                                                                                                                                                        .edges(
                                                                                                                                                                variantEdge -> variantEdge
                                                                                                                                                                        .node(
                                                                                                                                                                                variantNode -> variantNode
                                                                                                                                                                                        .title()
                                                                                                                                                                                        .price()
                                                                                                                                                                                        .compareAtPrice()
                                                                                                                                                                                        .availableForSale()
                                                                                                                                                                                        .weight()
                                                                                                                                                                                        .weightUnit()
                                                                                                                                                                                        .sku()
                                                                                                                                                                                        .selectedOptions(
                                                                                                                                                                                                optionQuery -> optionQuery
                                                                                                                                                                                                .name()
                                                                                                                                                                                                .value()
                                                                                                                                                                                        )
                                                                                                                                                                        )
                                                                                                                                                        )
                                                                                                                                        )
                                                                                                                        )
                                                                                                        )
                                                                                        )
                                                                        )
                                                        )
                                        )
                        )
        );
    }

    static Storefront.QueryRootQuery queryProducts(ID collectionID) {
        return Storefront.query(
                rootQuery -> rootQuery
                        .node(collectionID,
                                nodeQuery -> nodeQuery
                                        .onCollection(
                                                collectionQuery -> collectionQuery
                                                        .products(
                                                                arg -> arg.first(250),
                                                                productsQuery -> productsQuery
                                                                        .pageInfo(
                                                                                productPageQuery -> productPageQuery
                                                                                        .hasNextPage()
                                                                        )
                                                                        .edges(
                                                                                productEdgeQuery -> productEdgeQuery
                                                                                        .cursor()
                                                                                        .node(
                                                                                                productNodeQuery -> productNodeQuery
                                                                                                        .title()
                                                                                                        .descriptionHtml()
                                                                                                        .publishedAt()
                                                                                                        .updatedAt()
                                                                                                        .tags()
                                                                                                        .images(
                                                                                                                args -> args
                                                                                                                        .first(250),
                                                                                                                image -> image
                                                                                                                        .edges(
                                                                                                                                edge -> edge
                                                                                                                                        .node(
                                                                                                                                                node -> node
                                                                                                                                                        .src()
                                                                                                                                        )
                                                                                                                        )
                                                                                                        )
                                                                                                        .variants(
                                                                                                                args -> args.first(250),
                                                                                                                variantsQuery -> variantsQuery
                                                                                                                        .pageInfo(
                                                                                                                                variantsPageQuery -> variantsPageQuery
                                                                                                                                        .hasNextPage()
                                                                                                                        )
                                                                                                                        .edges(
                                                                                                                                variantsEdgeQuery -> variantsEdgeQuery
                                                                                                                                        .cursor()
                                                                                                                                        .node(
                                                                                                                                                variantsEdgeNodeQuery -> variantsEdgeNodeQuery
                                                                                                                                                        .title()
                                                                                                                                                        .price()
                                                                                                                                                        .compareAtPrice()
                                                                                                                                                        .sku()
                                                                                                                                                        .weight()
                                                                                                                                                        .weightUnit()
                                                                                                                                                        .availableForSale()
                                                                                                                                                        .selectedOptions(
                                                                                                                                                                opt -> opt
                                                                                                                                                                        .name()
                                                                                                                                                                        .value()
                                                                                                                                                        )
                                                                                                                                        )
                                                                                                                        )
                                                                                                        )
                                                                                        )
                                                                        )
                                                        )

                                        )
                        )
        );
    }

    static Storefront.QueryRootQuery queryUserDetails(String token) {
        return Storefront.query(
                rootQuery -> rootQuery
                        .customer(
                                token,
                                userQuery -> userQuery
                                        .id()
                                        .firstName()
                                        .lastName()
                                        .email()
                                        .acceptsMarketing()
                                        .displayName()
                                        .phone()
                                .defaultAddress(
                                        address -> address
                                                .firstName()
                                                .lastName()
                                                .address1()
                                                .address2()
                                                .phone()
                                                .company()
                                                .city()
                                                .country()
                                                .province()
                                                .zip()
                                )
                                .addresses(
                                        args -> args
                                        .first(25),
                                        address -> address
                                        .edges(
                                                edge -> edge
                                                .node(
                                                        node -> node
                                                                .firstName()
                                                                .lastName()
                                                                .address1()
                                                                .address2()
                                                                .phone()
                                                                .company()
                                                                .city()
                                                                .country()
                                                                .province()
                                                                .zip()
                                                )
                                        )
                                )
                        )
        );
    }

    static Storefront.QueryRootQuery queryUserAddresses(String token) {
        return Storefront.query(
                root -> root
                .customer(
                        token,
                        user -> user
                                .addresses(
                                        f -> f.first(25),
                                        addresses -> addresses
                                                .edges(
                                                        edge -> edge
                                                                .node(
                                                                        node -> node
                                                                                .firstName()
                                                                                .lastName()
                                                                                .address1()
                                                                                .address2()
                                                                                .phone()
                                                                                .company()
                                                                                .city()
                                                                                .country()
                                                                                .province()
                                                                                .zip()
                                                                )
                                                )
                                )
                )
        );
    }

    static Storefront.MutationQuery mutationForLoginUser(String email, String password) {
        Storefront.CustomerAccessTokenCreateInput input = new Storefront.CustomerAccessTokenCreateInput(
                email, password
        );

        return ClientMutation.mutationForLoginUser(input);
    }

    static Storefront.MutationQuery mutationForCreateUser(
            String email, String password, String firstName, String lastName
    ) {

        Storefront.CustomerCreateInput input = new Storefront
                .CustomerCreateInput(email, password)
                .setFirstName(firstName)
                .setLastName(lastName);

        return ClientMutation.mutationForCreateUser(
                input
        );
    }

}
