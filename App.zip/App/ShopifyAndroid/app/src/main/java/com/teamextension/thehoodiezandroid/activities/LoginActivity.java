/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputEditText;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.shopify.buy3.GraphCall;
import com.shopify.buy3.GraphError;
import com.shopify.buy3.GraphResponse;
import com.shopify.buy3.Storefront;
import com.teamextension.thehoodiezandroid.CommonUtils;
import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.managers.interfaces.BaseCallback;
import com.teamextension.thehoodiezandroid.managers.interfaces.NavigationToggleEvent;
import com.teamextension.thehoodiezandroid.model.CurrentUser;

public class LoginActivity extends AbstractActivity implements View.OnClickListener, NavigationToggleEvent {

    private static final String TAG = LoginActivity.class.getSimpleName();
    public static final String EVENT_SOURCE_KEY = "SOURCE";

    private EditText emailEditText = null;
    private TextInputEditText passEditText = null;
    private Button skipButton = null;
    private TextView registerLink = null;
    private Button loginActionButton = null;
    private TextView forgotPassword = null;

    private boolean mSource;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);

        mSource = getIntent().getBooleanExtra(EVENT_SOURCE_KEY, false);

        Toolbar mToolbar = findViewById(R.id.toolbar);
        ((TextView) mToolbar.findViewById(R.id.title)).setText(DataManager.getInstance().getShopName().toUpperCase());

        emailEditText = findViewById(R.id.emailInputField);
        passEditText = findViewById(R.id.passwordInputField);
        loginActionButton = findViewById(R.id.loginActionButton);
        skipButton = findViewById(R.id.skipBtn);
        registerLink = findViewById(R.id.registerActionLink);
        forgotPassword = findViewById(R.id.forgotPassword);

        loginActionButton.setOnClickListener(LoginActivity.this);
        forgotPassword.setOnClickListener(LoginActivity.this);
        if(mSource) {
            ImageButton backBtn = mToolbar.findViewById(R.id.backButton);
            backBtn.setVisibility(View.VISIBLE);
            backBtn.setOnClickListener(listener -> {
                LoginActivity.this.setResult(Activity.RESULT_CANCELED, getIntent());
                LoginActivity.this.finish();
            });
            registerLink.setVisibility(View.GONE);
            skipButton.setVisibility(View.GONE);
        } else {
            registerLink.setVisibility(View.VISIBLE);
            registerLink.setOnClickListener(LoginActivity.this);
            if(CommonUtils.ANONYMOUS_ACCOUNT_PERMISSION == CommonUtils.AccountStatus.ACCOUNT_NOT_REQUIRED) {
                skipButton.setOnClickListener(LoginActivity.this);
            } else {
                skipButton.setVisibility(View.GONE);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        LoginActivity.this.runOnUiThread(LoginActivity.this::enableNavigation);
        switch (resultCode) {
            case RESULT_OK:
                String email = data.getStringExtra("userEmail");
                String pass = data.getStringExtra("userPass");

                if(email != null && !email.isEmpty()) {
                    LoginActivity.this.emailEditText.setText(email);
                }

                if(pass != null && !pass.isEmpty()) {
                    LoginActivity.this.passEditText.setText(pass);
                }
                break;

            case RESULT_CANCELED:
                emailEditText.setText("");
                passEditText.setText("");
                break;

            default:
                Log.d(TAG, "onActivityResult: returned with code: " + resultCode);
                LoginActivity.this.showOnUiThread("An unknown error occurred with status code: " + resultCode);
                break;
        }
    }

    @Override
    public void onClick(View v) {
        LoginActivity.this.runOnUiThread(LoginActivity.this::disableNavigation);
        switch (v.getId()) {
            case R.id.loginActionButton:
                LoginActivity.this.login();
                break;
            case R.id.registerActionLink:
                LoginActivity.this.register();
                break;
            case R.id.forgotPassword:
                LoginActivity.this.resetPass();
                break;
            case R.id.skipBtn:
                LoginActivity.this.skip();
                break;
            default:
                LoginActivity.this.runOnUiThread(LoginActivity.this::enableNavigation);
        }
    }

    private void login() {
        String email = emailEditText.getText().toString();
        String pass = passEditText.getText().toString();

        boolean valid = validateFields(email, pass);

        if(valid) {
            DataManager.getInstance().login(
                    email,
                    pass,
                    new BaseCallback() {
                        @Override
                        public void onResponse(int status) {
                            if (mSource) {
                                LoginActivity.this.setResult(BaseCallback.RESULT_OK, getIntent());
                                LoginActivity.this.finish();
                            } else {
                                Intent goToMain = new Intent(LoginActivity.this, MainActivity.class);
                                LoginActivity.this.startActivity(goToMain);
                                LoginActivity.this.finish();
                            }
                        }

                        @Override
                        public void onFailure(final String message) {
                            LoginActivity.this.runOnUiThread(() -> {
                                showErrors(message);
                            });
                        }
                    }
            );
        } else {
            LoginActivity.this.runOnUiThread(LoginActivity.this::enableNavigation);
        }
    }

    private void register() {
        LoginActivity.this.runOnUiThread(() -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivityForResult(intent, 0);
        });
    }

    private void resetPass() {
        LoginActivity.this.runOnUiThread(() -> {
            Intent intent = new Intent(LoginActivity.this, ResetPasswordActivity.class);
            startActivityForResult(intent, 1);
        });
    }

    private void skip() {
        LoginActivity.this.runOnUiThread(() -> {
            Intent navigate = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(navigate);
            LoginActivity.this.finish();
        });
    }

    private void showErrors(String msg) {
        LoginActivity.this.enableNavigation();
        if(msg.toLowerCase().contains("customer")) {
            LoginActivity.this.emailEditText.setError(msg);
            return;
        }

        LoginActivity.this.showOnUiThread(msg);
    }

    private boolean validateFields(String email, String pass) {
        boolean valid = true;
        if(!CommonUtils.isNotEmpty(email)) {
            emailEditText.setError("Field cannot be empty");
            valid = false;
        } else if(!CommonUtils.isEmailValid(email)) {
            emailEditText.setError("Invalid email");
            valid = false;
        }

        if(!CommonUtils.isNotEmpty(pass)) {
            passEditText.setError("Field cannot be empty");
            valid = false;
        }

        return valid;
    }

    @Override
    public void enableNavigation() {
        LoginActivity.this.skipButton.setClickable(true);
        LoginActivity.this.skipButton.setFocusable(true);
        LoginActivity.this.registerLink.setClickable(true);
        LoginActivity.this.registerLink.setFocusable(true);
        LoginActivity.this.loginActionButton.setClickable(true);
        LoginActivity.this.loginActionButton.setFocusable(true);
        LoginActivity.this.forgotPassword.setClickable(true);
        LoginActivity.this.forgotPassword.setFocusable(true);
    }

    @Override
    public void disableNavigation() {
        LoginActivity.this.skipButton.setClickable(false);
        LoginActivity.this.skipButton.setFocusable(false);
        LoginActivity.this.registerLink.setClickable(false);
        LoginActivity.this.registerLink.setFocusable(false);
        LoginActivity.this.loginActionButton.setClickable(false);
        LoginActivity.this.loginActionButton.setFocusable(false);
        LoginActivity.this.forgotPassword.setClickable(false);
        LoginActivity.this.forgotPassword.setFocusable(false);
    }
}