/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.teamextension.thehoodiezandroid.CommonUtils;
import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.managers.interfaces.BaseCallback;
import com.teamextension.thehoodiezandroid.managers.interfaces.NavigationToggleEvent;

public class RegisterActivity extends AbstractActivity implements NavigationToggleEvent {

    private EditText emailField;
    private EditText passField;
    private EditText passConfirmField;
    private EditText firstNameField;
    private EditText lastNameField;
    private Button registerActionButton;

    private boolean mSource = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Toolbar mToolbar = findViewById(R.id.toolbar);
        ((TextView) mToolbar.findViewById(R.id.title)).setText(DataManager.getInstance().getShopName().toUpperCase());

        mSource = getIntent().getBooleanExtra(LoginActivity.EVENT_SOURCE_KEY, false);

        ImageView backButton = mToolbar.findViewById(R.id.backBtn);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegisterActivity.this.setResult(RESULT_CANCELED);
                RegisterActivity.this.finish();
            }
        });

        emailField = findViewById(R.id.register_emailField);
        passField = findViewById(R.id.register_passField);
        passConfirmField = findViewById(R.id.register_passFieldConfirm);
        firstNameField = findViewById(R.id.register_firstNameField);
        lastNameField = findViewById(R.id.register_lastNameField);

        registerActionButton = findViewById(R.id.registerActionButton);
        registerActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegisterActivity.this.runOnUiThread(RegisterActivity.this::disableNavigation);

                String email = emailField.getText().toString();
                String firstName = firstNameField.getText().toString();
                String lastName = lastNameField.getText().toString();
                String password = passField.getText().toString();
                String passwordConfirm = passConfirmField.getText().toString();

                boolean isValid = validateFields(email, password, passwordConfirm, firstName, lastName);

                if(isValid) {
                    sendRequest(email, password, firstName, lastName);
                } else {
                    RegisterActivity.this.runOnUiThread(RegisterActivity.this::enableNavigation);
                }
            }
        });
    }

    private void sendRequest(String email, String password, String firstName, String lastName) {
        DataManager.getInstance().register(
                email,
                password,
                firstName,
                lastName,
                false,
                new BaseCallback() {
                    @Override
                    public void onResponse(int status) {
                        if(status == RESULT_OK) {
                            Intent intent = new Intent();
                            intent.putExtra("userEmail", emailField.getText().toString());
                            intent.putExtra("userPass", passField.getText().toString());
                            RegisterActivity.this.setResult(Activity.RESULT_OK, intent);
                            RegisterActivity.this.finish();
                        } else {
                            onFailure("An unknown error occurred");
                        }
                    }

                    @Override
                    public void onFailure(final String message) {
                        RegisterActivity.this.runOnUiThread(() -> {
                            RegisterActivity.this.showError(message);
                        });
                        RegisterActivity.this.runOnUiThread(RegisterActivity.this::enableNavigation);
                    }
                }
        );
    }

    private boolean validateFields(String email, String password, String passwordConfirm, String firstName, String lastName) {
        boolean isValid = true;

        String emptyErrorMsg = RegisterActivity.this.getResources().getString(R.string.empty_field_error_message);
        if(email.isEmpty() || !CommonUtils.isEmailValid(email)) {
            if(email.isEmpty()) {
                emailField.setError(emptyErrorMsg);
            } else {
                emailField.setError("Invalid email address");
            }
            isValid = false;
        }

        if(firstName.isEmpty() || !CommonUtils.isNameValid(firstName)) {
            if(firstName.isEmpty()) {
                firstNameField.setError(emptyErrorMsg);
            } else {
                firstNameField.setError("Invalid first name");
            }
            isValid = false;
        }

        if(lastName.isEmpty() || !CommonUtils.isNameValid(lastName)) {
            if(lastName.isEmpty()) {
                lastNameField.setError(emptyErrorMsg);
            } else {
                lastNameField.setError("Invalid first name");
            }
            isValid = false;
        }

        boolean isPassValid = CommonUtils.isPasswordValid(password);
        if(password.isEmpty() || !isPassValid || !password.contentEquals(passwordConfirm)) {
            if(password.isEmpty()) {
                passField.setError(emptyErrorMsg);
            } else if(!isPassValid) {
                passField.setError("Password must contain at least 8 characters, 1 uppercase character, and 1 number");
            } else {
                passConfirmField.setError("Passwords do not match");
            }
            isValid = false;
        }

        return isValid;
    }

    private void showError(String msg) {
        if(msg.toLowerCase().contains("email")) {
            RegisterActivity.this.emailField.setError(msg);
            return;
        }

        if(msg.toLowerCase().contains("first")) {
            RegisterActivity.this.firstNameField.setError(msg);
            return;
        }

        if(msg.toLowerCase().contains("last")) {
            RegisterActivity.this.lastNameField.setError(msg);
            return;
        }

        if(msg.toLowerCase().contains("password")) {
            RegisterActivity.this.passField.setError(msg);
            return;
        }

        RegisterActivity.this.showOnUiThread(msg);
    }

    @Override
    public void enableNavigation() {
        RegisterActivity.this.registerActionButton.setClickable(true);
        RegisterActivity.this.registerActionButton.setFocusable(true);
    }

    @Override
    public void disableNavigation() {
        RegisterActivity.this.registerActionButton.setClickable(false);
        RegisterActivity.this.registerActionButton.setFocusable(false);
    }
}
