/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageButton;
import android.widget.TextView;

import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.managers.DataManager;

public class TermsActivity extends AbstractActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms);

        android.support.v7.widget.Toolbar mToolbar = findViewById(R.id.toolbar);
        ((TextView) mToolbar.findViewById(R.id.title)).setText(R.string.terms_and_conditions_text);
        ImageButton backBtn = mToolbar.findViewById(R.id.backButton);
        backBtn.setVisibility(View.VISIBLE);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TermsActivity.this.onBackPressed();
            }
        });

        WebView webView = findViewById(R.id.webView);
        webView.loadUrl(DataManager.getInstance().getShopTermsUrl());
    }
}
