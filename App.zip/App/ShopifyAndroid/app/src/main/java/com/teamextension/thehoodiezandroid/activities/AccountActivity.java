/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.activities;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.shopify.buy3.Storefront;
import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.managers.interfaces.BaseCallback;
import com.teamextension.thehoodiezandroid.model.CurrentUser;

public class AccountActivity extends AbstractActivity implements BaseCallback {

    public static final int RESULT_UPDATE = 100;
    public static final int RESULT_CREATE = 102;

    private static final String ADDRESSES_BUTTON_TEXT = "View all accounts & addresses (%d)";

    private ScrollView mContainer;
    private EditText mFirstName;
    private EditText mLastName;
    private EditText mAddress1;
    private EditText mAddress2;
    private EditText mZip;
    private EditText mCity;
    private EditText mCountry;
    private EditText mProvince;
    private EditText mCompany;
    private EditText mPhone;

    private TextView mEdit;

    private Button mAddNewAddress;
    private Button mAddressesBtn;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_details);

        Toolbar toolbar = findViewById(R.id.toolbar);

        TextView title = toolbar.findViewById(R.id.title);
        title.setText(R.string.account_activity_title);
        title.setAllCaps(false);
        ImageView backBtn = toolbar.findViewById(R.id.backButton);
        backBtn.setVisibility(View.VISIBLE);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AccountActivity.this.finish();
            }
        });

        mContainer = findViewById(R.id.default_address_container);
        mContainer.setVisibility(View.GONE);

        mAddNewAddress = findViewById(R.id.add_new_address);
        mAddNewAddress.setVisibility(View.VISIBLE);
        mAddNewAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent navigate = new Intent(AccountActivity.this, AddressUpdateActivity.class);
                startActivityForResult(navigate, RESULT_UPDATE);
            }
        });

        mFirstName = findViewById(R.id.account_details_firstName_value);
        mLastName = findViewById(R.id.account_details_lastName_value);
        mAddress1 = findViewById(R.id.account_details_address_1_value);
        mAddress2 = findViewById(R.id.account_details_address_2_value);
        mZip = findViewById(R.id.account_details_zip_value);
        mCity = findViewById(R.id.account_details_city_value);
        mCountry = findViewById(R.id.account_details_country_value);
        mProvince = findViewById(R.id.account_details_province_value);
        mCompany = findViewById(R.id.account_details_company_value);
        mPhone = findViewById(R.id.account_details_phone_value);

        mFirstName.setEnabled(false);
        mLastName.setEnabled(false);
        mAddress1.setEnabled(false);
        mAddress2.setEnabled(false);
        mZip.setEnabled(false);
        mCity.setEnabled(false);
        mCountry.setEnabled(false);
        mProvince.setEnabled(false);
        mCompany.setEnabled(false);
        mPhone.setEnabled(false);

        mEdit = findViewById(R.id.account_details_edit_link);
        mEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent navigate = new Intent(AccountActivity.this, AddressUpdateActivity.class);
                navigate.putExtra(AddressUpdateActivity.ADDRESS_ID_KEY,
                        CurrentUser.getInstance().getAddress() != null ?
                                CurrentUser.getInstance().getAddress().getId().toString() : ""
                );
                startActivityForResult(navigate, RESULT_UPDATE);
            }
        });

        mAddressesBtn = findViewById(R.id.account_details_view_addresses_button);

        mAddressesBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent navigate = new Intent(AccountActivity.this, AddressesActivity.class);
                navigate.putExtra(AddressUpdateActivity.ADDRESS_ID_KEY,
                        CurrentUser.getInstance().getAddress() != null ?
                        CurrentUser.getInstance().getAddress().getId().toString() : ""
                );
                startActivityForResult(navigate, RESULT_UPDATE);
            }
        });

        mAddressesBtn.setText(String.format(mAddressesBtn.getText().toString(), 0));

        TextView setDefault = findViewById(R.id.set_as_default);
        setDefault.setVisibility(View.GONE);

        DataManager.getInstance().userDetails(this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        onResponse(Activity.RESULT_OK);

        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onResponse(int status) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(CurrentUser.getInstance().getAddress() != null) {
                    mAddNewAddress.setVisibility(View.GONE);
                    mContainer.setVisibility(View.VISIBLE);

                    Storefront.MailingAddress address = CurrentUser.getInstance().getAddress();
                    mAddress1.setText((address.getAddress1() == null || address.getAddress1().isEmpty()) ? "-": address.getAddress1());
                    mAddress2.setText((address.getAddress2() == null || address.getAddress2().isEmpty()) ? "-": address.getAddress2());
                    mZip.setText((address.getZip() == null || address.getZip().isEmpty()) ? "-": address.getZip());
                    mCity.setText((address.getCity() == null || address.getCity().isEmpty()) ? "-": address.getCity());
                    mCountry.setText((address.getCountry().isEmpty()) ? "-": address.getCountry());
                    mFirstName.setText((address.getFirstName() == null || address.getFirstName().isEmpty()) ? CurrentUser.getInstance().getFirstName(): address.getFirstName());
                    mLastName.setText((address.getLastName() == null || address.getLastName().isEmpty()) ? CurrentUser.getInstance().getLastName(): address.getLastName());
                    mCompany.setText((address.getCompany() == null || address.getCompany().isEmpty()) ? "-": address.getCompany());
                    mPhone.setText((address.getPhone() == null || address.getPhone().isEmpty()) ? "-": address.getPhone());
                    mProvince.setText((address.getProvince() == null || address.getProvince().isEmpty()) ? "-": address.getProvince());
                } else {
                    mAddNewAddress.setVisibility(View.VISIBLE);
                    mContainer.setVisibility(View.GONE);
                }

                if(CurrentUser.getInstance().getShippingAddresses() != null && CurrentUser.getInstance().getShippingAddresses().size() != 0) {
                    mAddressesBtn.setText(String.format(ADDRESSES_BUTTON_TEXT, CurrentUser.getInstance().getShippingAddresses().size()));
                }

                mAddressesBtn.setBackgroundColor(Color.BLACK);
                mAddressesBtn.setTextColor(Color.WHITE);
                mAddressesBtn.setEnabled(true);
            }
        });
    }

    @Override
    public void onFailure(String message) {
        showOnUiThread(message);
    }
}
