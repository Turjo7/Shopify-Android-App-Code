/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.views.adapters;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.squareup.picasso.Picasso;
import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.model.ProductModel;

public class ViewPagerAdapter extends PagerAdapter{
    private Context context;
    private LayoutInflater layoutInflater;
    private ProductModel product;
    private DisplayMetrics mDm;

    public ViewPagerAdapter(Context context, ProductModel product){
        this.context = context;
        this.product = product;
        mDm = new DisplayMetrics();
        ((Activity)context).getWindowManager().getDefaultDisplay().getMetrics(mDm);
    }
    @Override
    public int getCount() {
        return product.getImages().length;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.image_for_single_product_layout, null);
        ImageView imageView = view.findViewById(R.id.imageViewCustom);
        imageView.setAdjustViewBounds(true);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        Picasso.with(context)
                .load(product.getImages()[position])
                .fit()
                .into(imageView);

        ViewPager vp = (ViewPager) container;

        vp.addView(view, 0);
        return view;


    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        ViewPager vp = (ViewPager) container;
        vp.setMinimumHeight(200);
        View v = (View) object;
        vp.removeView(v);
    }
}
