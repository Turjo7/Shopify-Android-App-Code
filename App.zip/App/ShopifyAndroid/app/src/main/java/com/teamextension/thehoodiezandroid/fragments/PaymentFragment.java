/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.fragments;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.shopify.buy3.CardClient;
import com.shopify.buy3.CreditCard;
import com.shopify.buy3.CreditCardVaultCall;
import com.shopify.buy3.Storefront;
import com.teamextension.thehoodiezandroid.CommonUtils;
import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.managers.interfaces.BaseCallback;
import com.teamextension.thehoodiezandroid.managers.interfaces.OnNavigationOccurred;
import com.teamextension.thehoodiezandroid.model.CurrentUser;
import com.teamextension.thehoodiezandroid.views.PaymentViewPager;

import java.io.IOException;

public class PaymentFragment extends AbstractCheckoutFragment {

    private TextView customerAddress = null;
    private TextView customerEditLink = null;
    private TextView billingAddress = null;
    private TextView shippingEditLink = null;
    private EditText cardNumberInputField = null;
    private EditText cardOwnerInputField = null;
    private EditText cardExpDateInputField = null;
    private EditText cardSecurityNoInputField = null;

    private CreditCard mCreditCard = null;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_payment, null);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        this.customerAddress = view.findViewById(R.id.payment_shipping_address_selected);
        this.customerEditLink = view.findViewById(R.id.payment_edit_shipping_link);
        this.billingAddress = view.findViewById(R.id.payment_billing_address_selected);
        this.shippingEditLink = view.findViewById(R.id.payment_edit_billing_link);

        this.cardNumberInputField = view.findViewById(R.id.payment_card_no_input);
        this.cardOwnerInputField = view.findViewById(R.id.payment_card_owner_input);
        this.cardExpDateInputField = view.findViewById(R.id.payment_card_date_input);
        this.cardSecurityNoInputField = view.findViewById(R.id.payment_card_cvv_input);

        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onStart() {
        super.onStart();
        if(cardNumberInputField != null && cardNumberInputField.getError() != null && !cardNumberInputField.getError().toString().isEmpty()) {
            PaymentFragment.this.showErrors("");
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if(cardNumberInputField != null && cardNumberInputField.getError() != null && !cardNumberInputField.getError().toString().isEmpty()) {
            PaymentFragment.this.showErrors("");
        }
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if(!hidden) {
            if(cardNumberInputField != null && cardNumberInputField.getError() != null && !cardNumberInputField.getError().toString().isEmpty()) {
                PaymentFragment.this.showErrors("");
            }
            setupData(DataManager.getInstance());
        }
    }

    @Override
    public boolean validateFields() {

        if(!PaymentFragment.this.isVisible()) {
            return false;
        }
        boolean result = true;

        String cardNo = getText(PaymentFragment.this.cardNumberInputField);
        String cardOwner = getText(PaymentFragment.this.cardOwnerInputField);
        String ownerFirstName = cardOwner.length() != 0 && cardOwner.contains(" ") ? cardOwner.substring(0, cardOwner.indexOf(' ')): "";
        String ownerLastName = cardOwner.length() != 0 && cardOwner.contains(" ") ? cardOwner.substring(cardOwner.indexOf(' ') + 1): "";
        String cardDate = getText(PaymentFragment.this.cardExpDateInputField);
        String cardSecurity = getText(PaymentFragment.this.cardSecurityNoInputField);

        if(cardNo.length() != 12) {
            this.cardNumberInputField.setError("Invalid card number");
            result = false;
        }

        if(!CommonUtils.isNameValid(ownerFirstName) || !CommonUtils.isNameValid(ownerLastName)) {
            this.cardNumberInputField.setError("Invalid card number");
            result = false;
        }

        if(cardDate.isEmpty()) {
            this.cardNumberInputField.setError("Invalid card number");
            result = false;
        }

        if(cardSecurity.length() != 3) {
            this.cardNumberInputField.setError("Invalid card number");
            result = false;
        }

        if(result) {
            mCreditCard = CreditCard.builder()
                    .firstName(ownerFirstName)
                    .lastName(ownerLastName)
                    .expireMonth(cardDate)
                    .expireYear(cardDate)
                    .number(cardNo)
                    .build();
        }

        return result;
    }

    public void placeOrder(final PaymentViewPager.OnPaymentOccurred callback) {
        if(PaymentFragment.this.validateFields()) {
            new CardClient().vault(mCreditCard, DataManager.getInstance().getCheckout().getWebUrl()).enqueue(new CreditCardVaultCall.Callback() {
                @Override
                public void onResponse(@NonNull String token) {
                    DataManager.getInstance().placeOrder(token, new BaseCallback() {
                        @Override
                        public void onResponse(int status) {
                            if(status == RESULT_OK) {
                                PaymentViewPager.OnPaymentOccurred.ResponseData result = new PaymentViewPager.OnPaymentOccurred.Builder<String>()
                                        .code(PaymentViewPager.OnPaymentOccurred.ResponseData.ResponseCodes.STATUS_OK)
                                        .data(token)
                                        .status(PaymentViewPager.OnPaymentOccurred.Status.SUCCESS)
                                        .build();

                                callback.onPaymentOccurred(result);
                            } else {
                                onFailure("Unknown error occurred");
                            }
                        }

                        @Override
                        public void onFailure(String message) {
                            if(message.toLowerCase().contains("invalid")) {
                                PaymentFragment.this.showErrors(message);
                                return;
                            }

                            PaymentViewPager.OnPaymentOccurred.ResponseData<String> result = new PaymentViewPager.OnPaymentOccurred.Builder<String>()
                                    .code(PaymentViewPager.OnPaymentOccurred.ResponseData.ResponseCodes.STATUS_FAIL)
                                    .data(message)
                                    .status(PaymentViewPager.OnPaymentOccurred.Status.COULD_NOT_BE_COMPLETED)
                                    .build();
                            callback.onPaymentOccurred(result);
                        }
                    });
                }

                @Override
                public void onFailure(@NonNull IOException error) {
                    //TODO: Maybe check for internet connection
                    PaymentViewPager.OnPaymentOccurred.ResponseData<IOException> result = new PaymentViewPager.OnPaymentOccurred.Builder<IOException>()
                            .code(PaymentViewPager.OnPaymentOccurred.ResponseData.ResponseCodes.STATUS_FAIL)
                            .data(error)
                            .status(PaymentViewPager.OnPaymentOccurred.Status.COULD_NOT_BE_COMPLETED)
                            .build();

                    if(error.getLocalizedMessage().toLowerCase().contains("card")) {
                        PaymentFragment.this.showErrors("Invalid credit card");
                    }
                    callback.onPaymentOccurred(result);
                }
            });
        } else {
            callback.onPaymentOccurred(
                    new PaymentViewPager.OnPaymentOccurred.Builder<Void>()
                    .data(null)
                    .code(-1)
                    .status(PaymentViewPager.OnPaymentOccurred.Status.ERROR)
                    .build()
            );
        }
    }

    @Override
    public void setupData(DataManager manager) {
        setupSelectedAddresses(manager);
    }

    @Override
    public void showErrors(final String error) {
        Activity a = PaymentFragment.this.getActivity();
        if (a != null) {
            a.runOnUiThread(() -> {
                this.cardNumberInputField.setError(error);
            });
        }
    }

    private void setupSelectedAddresses(final DataManager manager) {
        Activity a =  PaymentFragment.this.getActivity();

        if(a != null) {
            a.runOnUiThread(() -> {
                String savedAddress1 = PaymentFragment.this.stringifyAddress1(manager);
                String savedAddress2 = PaymentFragment.this.stringifyAddress2(manager);
                String address1 = (!savedAddress1.isEmpty() && !savedAddress1.toLowerCase().contentEquals(PaymentFragment.this.customerAddress.getText().toString().toLowerCase())) ?
                        savedAddress1:
                        PaymentFragment.this.customerAddress.getText().toString();
                String address2 = (!savedAddress2.isEmpty() && !savedAddress2.toLowerCase().contentEquals(PaymentFragment.this.billingAddress.getText().toString().toLowerCase())) ?
                        savedAddress2:
                        PaymentFragment.this.billingAddress.getText().toString();
                PaymentFragment.this.customerAddress.setText(address1);
                PaymentFragment.this.billingAddress.setText(address2);

                PaymentFragment.this.customerEditLink.setOnClickListener(v -> {
                    if (PaymentFragment.this.onNavigationOccurred != null) {
                        PaymentFragment.this.onNavigationOccurred.onNavigationOccurred(OnNavigationOccurred.Direction.CUSTOMER);
                    }
                });

                PaymentFragment.this.shippingEditLink.setOnClickListener(v -> {
                    if (PaymentFragment.this.onNavigationOccurred != null) {
                        PaymentFragment.this.onNavigationOccurred.onNavigationOccurred(OnNavigationOccurred.Direction.SHIPPING);
                    }
                });
            });
        }
    }

    private String stringifyAddress1(DataManager manager) {
        Storefront.Checkout checkout = manager.getCheckout();
        Storefront.MailingAddress address = (checkout != null && checkout.getShippingAddress() != null) ? checkout.getShippingAddress(): null;
        Storefront.MailingAddress userAddress = !CurrentUser.getInstance().getAccessToken().isEmpty() ? CurrentUser.getInstance().getAddress():
                null;

        String address2 = "";

        if(checkout != null && address != null) {
            address2 = address.getAddress1() + ' ' + address.getCity() + ' ' + address.getProvince() + ' ' + address.getZip();
        } else if(userAddress != null){
            address2 = userAddress.getAddress1() + ' ' + userAddress.getCity() + ' ' + userAddress.getProvince() + ' ' + userAddress.getZip();
        }

        return address2;

    }

    private String stringifyAddress2(DataManager manager) {
        Storefront.MailingAddress address = manager.getBillingAddress();
        Storefront.MailingAddress checkoutAddress = manager.getCheckout() != null ? manager.getCheckout().getShippingAddress(): null;
        Storefront.MailingAddress userAddress = !CurrentUser.getInstance().getAccessToken().isEmpty() ? CurrentUser.getInstance().getAddress(): null;

        String address2 = "";

        if(address != null) {
            address2 = address.getAddress1() + ' ' + address.getCity() + ' ' + address.getProvince() + ' ' + address.getZip();
        } else if(checkoutAddress != null) {
            address2 = checkoutAddress.getAddress1() + ' ' + checkoutAddress.getCity() + ' ' + checkoutAddress.getProvince() + ' ' + checkoutAddress.getZip();
        } else if(userAddress != null){
            address2 = userAddress.getAddress1() + ' ' + userAddress.getCity() + ' ' + userAddress.getProvince() + ' ' + userAddress.getZip();
        }

        return address2;
    }
}
