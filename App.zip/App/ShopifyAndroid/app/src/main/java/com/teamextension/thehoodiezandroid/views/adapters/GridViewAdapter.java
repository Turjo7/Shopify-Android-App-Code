/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.views.adapters;

import android.content.Context;
import android.graphics.Paint;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.ArraySet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.managers.interfaces.NavigationInterface;
import com.teamextension.thehoodiezandroid.model.ProductModel;
import com.teamextension.thehoodiezandroid.model.SelectedOptions;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Observable;
import java.util.Observer;
import java.util.Set;


public class GridViewAdapter extends ArrayAdapter<ProductModel> implements AdapterView.OnItemClickListener, Observer{

    private static final String SHOP_CURRENCY = DataManager.getInstance().getShopCurrency();

    private ArrayList<ProductModel> products = new ArrayList<>();
    private ArrayList<ProductModel> data = new ArrayList<>();
    private Context context = null;
    private NavigationInterface navigationInterface = null;
    private SelectedOptions selectedOptions = new SelectedOptions();

    public GridViewAdapter(@NonNull Context context, ArrayList<ProductModel> prods) {
        super(context, 0, prods);
        this.context = context;
        if(context instanceof NavigationInterface){
            navigationInterface = (NavigationInterface) context;
        }
        this.products = prods;
        updateList();
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ProductModel singleItem = data.get(position);
        GridItemHolder holder;
        if(convertView == null){
            holder = new GridItemHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.collection_grid_item_layout, parent, false);

            holder.label = convertView.findViewById(R.id.label);
            holder.itemImage = convertView.findViewById(R.id.itemImage);
            holder.productTitle = convertView.findViewById(R.id.productTitle);
            holder.oldPrice = convertView.findViewById(R.id.oldPrice);
            holder.newPrice = convertView.findViewById(R.id.newPrice);
            convertView.setTag(holder);
        } else {
            holder = (GridItemHolder) convertView.getTag();
        }
        holder.label.setText(R.string.sale_text);
        holder.productTitle.setText(singleItem.getTitle());
        Picasso.with(context)
                .load(singleItem.getImages()[0])
                .fit()
                .into(holder.itemImage);

        if(singleItem.getVariants().get(0).getOldPrice() != null &&
                singleItem.getVariants().get(0).getOldPrice().compareTo(singleItem.getVariants().get(0).getPrice()) > 0 &&
                singleItem.getVariants().get(0).isAvailableForSale()) {
            holder.oldPrice.setText(singleItem.getVariants().get(0).getOldPrice().toString() + ' ' +
                    SHOP_CURRENCY);
            holder.oldPrice.setPaintFlags(holder.oldPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);

            holder.label.setVisibility(View.VISIBLE);
            holder.newPrice.setVisibility(View.VISIBLE);
            holder.newPrice.setText(singleItem.getVariants().get(0).getPrice().toString() + ' ' +
                    SHOP_CURRENCY);
        }  else {
            holder.newPrice.setVisibility(View.INVISIBLE);
            holder.oldPrice.setVisibility(View.VISIBLE);
            holder.label.setVisibility(View.INVISIBLE);
            holder.oldPrice.setText(singleItem.getVariants().get(0).getPrice().toString() + ' ' +
                    SHOP_CURRENCY);
        }

        return convertView;
    }

    @Override
    public int getCount() {
        return data != null ? data.size() : 0;
    }

    public void sortAtoZ(){
        this.data.sort(new Comparator<ProductModel>() {
            @Override
            public int compare(ProductModel o1, ProductModel o2) {
                return o1.getTitle().compareTo(o2.getTitle());
            }
        });
        notifyDataSetChanged();
    }

    public void sortZtoA(){
        this.data.sort(new Comparator<ProductModel>() {
            @Override
            public int compare(ProductModel o1, ProductModel o2) {
                return -(o1.getTitle().compareTo(o2.getTitle()));
            }
        });
        notifyDataSetChanged();
    }

    public void sortHighToLow(){
        this.data.sort(new Comparator<ProductModel>() {
            @Override
            public int compare(ProductModel o1, ProductModel o2) {
                return -(o1.getPrice().compareTo(o2.getPrice()));
            }
        });
        notifyDataSetChanged();
    }

    public void sortLowToHigh(){
        this.data.sort(new Comparator<ProductModel>() {
            @Override
            public int compare(ProductModel o1, ProductModel o2) {
                return o1.getPrice().compareTo(o2.getPrice());
            }
        });
        notifyDataSetChanged();
    }

    public void sortNewtoOld(){
        this.data.sort(new Comparator<ProductModel>() {
            @Override
            public int compare(ProductModel o1, ProductModel o2) {
                return o1.getPublishedAt().compareTo(o2.getPublishedAt());
            }
        });
        notifyDataSetChanged();
    }
    public void sortOldtoNew(){
        this.data.sort(new Comparator<ProductModel>() {
            @Override
            public int compare(ProductModel o1, ProductModel o2) {
                return -(o1.getPublishedAt().compareTo(o2.getPublishedAt()));
            }
        });
        notifyDataSetChanged();
    }
    public void setData(ArrayList<ProductModel> prods){
        this.data = prods;
        notifyDataSetChanged();
    }


    public void searchProducts(String newText){
        data = new ArrayList<>();
        if(newText.isEmpty()) {
            data.addAll(products);
            this.notifyDataSetChanged();
            return;
        }

        ArrayList<ProductModel> aux = new ArrayList<>();
        for (ProductModel p : products) {
            if (p.getTitle().toLowerCase().contains(newText.toLowerCase())) {
                aux.add(p);
            }
        }
        data.addAll(aux);
        this.notifyDataSetChanged();
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        navigationInterface.navigateToProduct(data.get(i).getID().toString());
    }

    public void updateList(){
        data = new ArrayList<>();
        ArrayList<ProductModel> aux = new ArrayList<>();

        for(ProductModel p : products){
            if(
                    p.containsSelectedOption("Color", selectedOptions.getColor()) &&
                            p.containsSelectedOption("Size", selectedOptions.getSize()) &&
                            p.containsSelectedOption("Material", selectedOptions.getMaterial())
                    ) {

                if(selectedOptions.getLowerPrice() == selectedOptions.getHigherPrice() || p.between(p.getPrice().doubleValue(), selectedOptions.getLowerPrice(), selectedOptions.getHigherPrice())) {
                    if (selectedOptions.getSearchCriteria().isEmpty()) {
                        aux.add(p);
                    } else if (p.getTitle().toLowerCase().contains(selectedOptions.getSearchCriteria().toLowerCase())) {
                        aux.add(p);
                    }
                }
            }
        }
        data.addAll(aux);
        this.notifyDataSetChanged();
    }

    @Override
    public void update(Observable observable, Object o) {
        if(observable instanceof SelectedOptions) {
            selectedOptions = (SelectedOptions) observable;
            this.updateList();
        }
    }
}

class GridItemHolder{
    protected TextView label;
    protected ImageView itemImage;
    protected TextView productTitle;
    protected TextView oldPrice;
    protected TextView newPrice;
}
