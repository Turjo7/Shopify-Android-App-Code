/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.managers;

import android.content.Context;

import com.shopify.buy3.GraphCall;
import com.shopify.buy3.GraphClient;
import com.shopify.buy3.HttpCachePolicy;
import com.shopify.buy3.MutationGraphCall;
import com.shopify.buy3.QueryGraphCall;
import com.shopify.buy3.RetryHandler;
import com.shopify.buy3.Storefront;
import com.shopify.buy3.pay.PaymentToken;
import com.shopify.graphql.support.ID;
import com.shopify.graphql.support.Nullable;
import com.teamextension.thehoodiezandroid.model.CurrentUser;

import java.util.UUID;

public final class GraphClientManager {
    private static final String SHOP_DOMAIN = "c5-features-store.myshopify.com";
    private static final String API_KEY = "c5cc161e9f97fc43e850d27af0fe0c4d";
    public static final String MERCHANT_ID = "merchant.estore.your.id";
    public static final String PUBLIC_KEY = "BOSJcwUSqSSNm8EnmlKYBRRjeCtPvCJpSkjUxWUjOCl1G5FoI6uIzVi77dA+Rola/LphZDaLVCn7Ttd8OO3Offs=";
    public static final String IDEMPOTENCY_KEY = UUID.randomUUID().toString();

    private GraphClient mClient;

    GraphClientManager(Context context) {
        mClient = GraphClient.builder(context)
                .shopDomain(SHOP_DOMAIN)
                .accessToken(API_KEY)
                .defaultHttpCachePolicy(HttpCachePolicy.CACHE_FIRST)
                .build();
    }

    void getShop(GraphCall.Callback<Storefront.QueryRoot> callback) {
        Storefront.QueryRootQuery query = ClientQuery.queryForShop();
        mClient
                .queryGraph(query)
                .enqueue(callback);
    }

    void getCollections(GraphCall.Callback<Storefront.QueryRoot> callback) {
        Storefront.QueryRootQuery query = ClientQuery.queryCollections();
        QueryGraphCall call = mClient.queryGraph(query);

        call.enqueue(callback);
    }

    void getProducts(ID collectionID, GraphCall.Callback<Storefront.QueryRoot> callback) {
        Storefront.QueryRootQuery query = ClientQuery.queryProducts(collectionID);
        QueryGraphCall call = mClient.queryGraph(query);

        call.enqueue(callback);
    }

    void login(String email, String password, GraphCall.Callback<Storefront.Mutation> callback) {
        Storefront.CustomerAccessTokenCreateInput input = new Storefront.CustomerAccessTokenCreateInput(email, password);
        Storefront.MutationQuery query = ClientMutation.mutationForLoginUser(input);
        MutationGraphCall call = mClient.mutateGraph(query);

        call.enqueue(callback, null, RetryHandler.NO_RETRY);
    }

    void register(String email, String password, String firstName, String lastName, @Nullable boolean acceptsMarketing,
                  GraphCall.Callback<Storefront.Mutation> callback) {
        Storefront.MutationQuery query = ClientQuery.mutationForCreateUser(
                email, password, firstName, lastName
        );
        MutationGraphCall call = mClient.mutateGraph(query);

        call.enqueue(callback);
    }

    void getUserDetails(String token, GraphCall.Callback<Storefront.QueryRoot> callback) {
        Storefront.QueryRootQuery query = ClientQuery.queryUserDetails(token);
        mClient.queryGraph(query).enqueue(callback);
    }

    void getUserAddresses(String token, GraphCall.Callback<Storefront.QueryRoot> callback) {
        Storefront.QueryRootQuery query = ClientQuery.queryUserAddresses(token);
        mClient.queryGraph(query).enqueue(callback);
    }

    void updateUserDetails(
            String firstName, String lastName, String phone,
            GraphCall.Callback<Storefront.Mutation> callback
    ) {
        Storefront.MutationQuery query = ClientMutation.mutationForUpdateUser(
                CurrentUser.getInstance().getAccessToken(),
                firstName, lastName, phone
        );
        mClient.mutateGraph(query).enqueue(callback);
    }

    void updateUserDefaultAddress(
            ID addressId,
            GraphCall.Callback<Storefront.Mutation> callback
    ) {
        Storefront.MutationQuery query = ClientMutation.mutationForUpdateBillingAddress(
                CurrentUser.getInstance().getAccessToken(), addressId
        );

        mClient.mutateGraph(query).enqueue(callback);
    }

    void createUserAddress(
            String firstName, String lastName, String phone, String company, String address1, String address2, String city, String province, String country, String zip,
            GraphCall.Callback<Storefront.Mutation> callback
    ) {
        Storefront.MutationQuery query = ClientMutation.mutationForCreateAddress(
                CurrentUser.getInstance().getAccessToken(),
                firstName, lastName, phone, company,
                address1, address2, city, province,
                country, zip
        );

        mClient.mutateGraph(query).enqueue(callback);
    }

    void updateUserAddress(
            String addressId, String firstName, String lastName, String phone, String address1, String address2, String company, String city, String province, String country, String zip,
            GraphCall.Callback<Storefront.Mutation> callback
    ) {
        Storefront.MutationQuery query = ClientMutation.mutationForUpdateAddress(
                CurrentUser.getInstance().getAccessToken(), addressId,
                firstName, lastName, phone,
                company, address1, address2,
                city, province, zip, country
        );

        mClient.mutateGraph(query).enqueue(callback);
    }

    void createCheckout(GraphCall.Callback<Storefront.Mutation> callback) {
        Storefront.MutationQuery query = ClientMutation.mutationForCreateCheckout(CurrentUser.getInstance().getEmail());

        mClient.mutateGraph(query).enqueue(callback);
    }

    void updateCheckoutEmail(ID checkoutId, String email, GraphCall.Callback<Storefront.Mutation> callback) {
        Storefront.MutationQuery query = ClientMutation.createUpdateCheckoutEmail(checkoutId.toString(), email);

        mClient.mutateGraph(query).enqueue(callback);
    }

    void updateCheckoutAddress(ID checkoutId, Storefront.MailingAddress address, GraphCall.Callback<Storefront.Mutation> callback) {
        Storefront.MutationQuery query = ClientMutation.createUpdateCheckoutAddress(
                checkoutId.toString(), address.getAddress1(),
                address.getAddress2(),address.getFirstName(),
                address.getLastName(), address.getPhone(),
                address.getZip(), address.getCity(),
                address.getCountry(), address.getProvince());

        mClient.mutateGraph(query).enqueue(callback);
    }

    void resetUserPassword(String email, GraphCall.Callback<Storefront.Mutation> callback) {
        Storefront.MutationQuery query = ClientMutation.mutationForRecoverPassword(email);

        mClient.mutateGraph(query).enqueue(callback);
    }

    void placeOrder(String token, PaymentMethod method, GraphCall.Callback<Storefront.Mutation> callback) {
        Storefront.MutationQuery query = null;

        switch (method) {
            case CARD_PAYMENT:
                query = ClientMutation.createCreditCardOrder(token);
                break;
            case GOOGLE_PAY:
                query = ClientMutation.createGooglePayOrder(token);
                break;
        }

        mClient.mutateGraph(query).enqueue(callback);
    }
}

enum PaymentMethod {
    CARD_PAYMENT, GOOGLE_PAY
}