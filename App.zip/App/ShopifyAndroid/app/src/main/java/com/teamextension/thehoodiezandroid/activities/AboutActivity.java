/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.activities;


import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.managers.DataManager;

public class AboutActivity extends AbstractActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        android.support.v7.widget.Toolbar mToolbar = findViewById(R.id.toolbar);
        ((TextView) mToolbar.findViewById(R.id.title)).setText(R.string.about_us_text);
        ImageButton backBtn = mToolbar.findViewById(R.id.backButton);
        backBtn.setVisibility(View.VISIBLE);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AboutActivity.this.onBackPressed();
            }
        });

       TextView name = findViewById(R.id.shop_title);
       name.setText(DataManager.getInstance().getShopName());

       TextView desc = findViewById(R.id.shop_description);
       desc.setText(DataManager.getInstance().getShopDescription());
    }
}
