/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.activities;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.model.CollectionModel;
import com.teamextension.thehoodiezandroid.model.CurrentUser;

import java.util.ArrayList;

public abstract class BaseActivity extends AbstractActivity {

    protected ArrayList<CollectionModel> mCollections = new ArrayList<CollectionModel>();
    protected android.support.v7.widget.Toolbar mToolbar;
    protected DrawerLayout mDrawer;
    private ActionBarDrawerToggle mDrawerToggle;

    public BaseActivity() {
        mCollections = DataManager.getInstance().getCollections();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    protected void initNavigation() {
        TextView title = (TextView) mToolbar.findViewById(R.id.title);
        title.setText(DataManager.getInstance().getShopName());

        initDrawer();

        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawer, mToolbar, R.string.open, R.string.close);
        mDrawer.addDrawerListener(mDrawerToggle);

        mDrawerToggle.syncState();
    }

    protected abstract void initDrawer();

    protected void initMenuOptions(Menu menu) {
        final Resources res = getResources();
        MenuItem.OnMenuItemClickListener menuItemListener = new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Intent navigate = null;
                if (item.getTitle().toString().contentEquals(res.getString(R.string.my_account_text))) {
                    navigate = new Intent(BaseActivity.this, AccountActivity.class);
                } else if (item.getTitle().toString().contentEquals(res.getString(R.string.terms_and_conditions_text))) {
                    navigate = new Intent(BaseActivity.this, TermsActivity.class);
                } else if (item.getTitle().toString().contentEquals(res.getString(R.string.privacy_policy_text))) {
                    navigate = new Intent(BaseActivity.this, PrivacyPolicyActivity.class);
                } else if (item.getTitle().toString().contentEquals(res.getString(R.string.about_us_text))) {
                    navigate = new Intent(BaseActivity.this, AboutActivity.class);
                }

                if (navigate != null) {
                    BaseActivity.this.startActivity(navigate);
                    mDrawer.closeDrawer(Gravity.START);
                } else {
                    showOnUiThread("Cannot navigate");
                }

                return false;
            }
        };

        menu.add(res.getString(R.string.my_account_text)).setOnMenuItemClickListener(menuItemListener).setVisible(CurrentUser.getInstance().getId() != null);
        menu.add(res.getString(R.string.about_us_text)).setOnMenuItemClickListener(menuItemListener);
        menu.add(res.getString(R.string.terms_and_conditions_text)).setOnMenuItemClickListener(menuItemListener);
        menu.add(res.getString(R.string.privacy_policy_text)).setOnMenuItemClickListener(menuItemListener);

    }

    protected void rebuildDrawer() {
        NavigationView optionsContainer = mDrawer.findViewById(R.id.drawer_options_container);
        Menu menu = optionsContainer.getMenu();
        MenuItem item = menu.getItem(0);
        item.setVisible(!CurrentUser.getInstance().getAccessToken().isEmpty());
    }
}
