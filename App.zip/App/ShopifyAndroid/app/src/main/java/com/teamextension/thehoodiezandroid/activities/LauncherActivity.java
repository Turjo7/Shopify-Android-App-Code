/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.teamextension.thehoodiezandroid.CommonUtils;
import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.managers.interfaces.BaseCallback;

public class LauncherActivity extends AbstractActivity implements BaseCallback {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);

        TextView title = findViewById(R.id.appTitle);

        // Request shop details
        DataManager.getInstance().setClientManager(LauncherActivity.this);
        DataManager.getInstance().requestShop(new BaseCallback() {
            @Override
            public void onResponse(int status) {
                if(status == 200) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            title.setText(DataManager.getInstance().getShopName());

                            //  Request Collections from server
                            DataManager.getInstance().collections(LauncherActivity.this);
                        }
                    });
                } else {
                    this.onFailure("An unknown error has occurred");
                }
            }

            @Override
            public void onFailure(String message) {
                showOnUiThread(message);
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    // Request Collections Callback
    @Override
    public void onResponse(int status) {
        if(status == 200) {
            Intent launchNext;

            if(CommonUtils.FIRST_SCREEN_FLAG == 0) {
                launchNext = new Intent(LauncherActivity.this, MainActivity.class);
            } else {
                launchNext = new Intent(LauncherActivity.this, LoginActivity.class);
            }

            LauncherActivity.this.startActivity(launchNext);
            LauncherActivity.this.finish();
        } else {
            this.onFailure("An unknown error has occurred");
        }
    }

    @Override
    public void onFailure(String message) {
        showOnUiThread(message);
    }
}
