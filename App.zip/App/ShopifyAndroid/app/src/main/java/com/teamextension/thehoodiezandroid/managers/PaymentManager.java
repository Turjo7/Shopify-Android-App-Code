/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.managers;

import android.app.Activity;
import android.util.Pair;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.wallet.AutoResolveHelper;
import com.google.android.gms.wallet.CardRequirements;
import com.google.android.gms.wallet.IsReadyToPayRequest;
import com.google.android.gms.wallet.PaymentDataRequest;
import com.google.android.gms.wallet.PaymentMethodTokenizationParameters;
import com.google.android.gms.wallet.PaymentsClient;
import com.google.android.gms.wallet.TransactionInfo;
import com.google.android.gms.wallet.Wallet;
import com.google.android.gms.wallet.WalletConstants;
import com.teamextension.thehoodiezandroid.managers.interfaces.BaseCallback;

import java.util.Arrays;
import java.util.List;

public class PaymentManager {
    public static final boolean ENABLE_GOOGLE_PAY = true;
    public static final int LOAD_PAYMENT_DATA_REQUEST_CODE = 110;

    private PaymentsClient mPaymentsClient = null;
    private PaymentDataRequest.Builder mRequestBuilder = null;

    void getClient(Activity activity) {
        if(mPaymentsClient == null) {
            mPaymentsClient = Wallet.getPaymentsClient(
                    activity,
                    new Wallet.WalletOptions.Builder()
                            .setEnvironment(PaymentUtils.ENVIRONMENT)
                            .build()
            );
        }

    }

    public void isReadyToPay(final BaseCallback callback) {
        IsReadyToPayRequest.Builder requestBuilder = IsReadyToPayRequest.newBuilder();
        for(Integer i: PaymentUtils.ALLOWED_PAYMENT_METHODS) {
            requestBuilder.addAllowedPaymentMethod(i);
        }

        IsReadyToPayRequest request = requestBuilder.build();
        mPaymentsClient.isReadyToPay(request).addOnCompleteListener(
                listener -> {
                    try {
                        boolean result = listener.getResult(ApiException.class);
                        if(result) {
                            callback.onResponse(BaseCallback.RESULT_OK);
                        } else {
                            callback.onResponse(BaseCallback.RESULT_FAILED);
                        }
                    } catch (ApiException e) {
                        e.printStackTrace();
                        callback.onFailure(e.getLocalizedMessage());
                    }
                }
        );
    }

    public PaymentManager createPaymentDataRequest() {
        mRequestBuilder = PaymentDataRequest.newBuilder()
                .setTransactionInfo(
                        TransactionInfo.newBuilder()
                        .setTotalPriceStatus(WalletConstants.TOTAL_PRICE_STATUS_FINAL)
                        .setTotalPrice(String.valueOf(DataManager.getInstance().getProductsPrice()))
                        .setCurrencyCode(PaymentUtils.CURRENCY_CODE)
                        .build()
                )
                .setPaymentMethodTokenizationParameters(PaymentMethodTokenizationParameters.newBuilder()
                        .setPaymentMethodTokenizationType(
                                WalletConstants.PAYMENT_METHOD_TOKENIZATION_TYPE_PAYMENT_GATEWAY
                        )
                        .addParameter(
                                PaymentUtils.buildGateway().first,
                                PaymentUtils.buildGateway().second
                        )
                        .addParameter(
                                PaymentUtils.buildMerchant().first,
                                PaymentUtils.buildMerchant().second
                        )
//                        .addParameter(    //TODO: use publicKey here?
//                              PaymentUtils.buildKey().first,
//                              PaymentUtils.buildKey().second
//                        )
                        .build()
                )
                .setCardRequirements(
                    CardRequirements.newBuilder()
                            .addAllowedCardNetworks(PaymentUtils.ALLOWED_CARD_NETWORKS)
                            .setAllowPrepaidCards(PaymentUtils.ALLOW_PREPAID_CARDS)
                            .setBillingAddressFormat(WalletConstants.BILLING_ADDRESS_FORMAT_FULL)
                            .setBillingAddressRequired(PaymentUtils.REQUIRE_BILLING_ADDRESS)
                            .build()
                )
                .setPhoneNumberRequired(PaymentUtils.REQUIRE_PHONE_NUMBER)
                .setEmailRequired(PaymentUtils.REQUIRE_EMAIL_ADDRESS)
                .setShippingAddressRequired(PaymentUtils.REQUIRE_SHIPPING_ADDRESS)
                .addAllowedPaymentMethod(WalletConstants.PAYMENT_METHOD_CARD)
                .addAllowedPaymentMethod(WalletConstants.PAYMENT_METHOD_TOKENIZED_CARD)
                .setUiRequired(PaymentUtils.REQUIRE_UI);
        return this;
    }

    public void placePayment(Activity activity) {
        if(mRequestBuilder != null) {
            PaymentDataRequest request = mRequestBuilder.build();
            AutoResolveHelper.resolveTask(
                    mPaymentsClient.loadPaymentData(request),
                    activity,
                    LOAD_PAYMENT_DATA_REQUEST_CODE
            );
        }
    }

    public void closeConnection() {
        mPaymentsClient = null;
        mRequestBuilder = null;
    }

    public static class Builder {
        private PaymentManager manager = null;

        public Builder getInstance() {
            if(manager == null) {
                manager = new PaymentManager();
            }

            return this;
        }

        public Builder with(Activity activity) {
            manager.getClient(activity);
            return this;
        }

        public PaymentManager build() {
            return this.manager;
        }
    }
}

class PaymentUtils {
    public static final boolean REQUIRE_PHONE_NUMBER = true;
    public static final boolean REQUIRE_EMAIL_ADDRESS = true;
    public static final boolean REQUIRE_SHIPPING_ADDRESS = true;
    public static final boolean REQUIRE_BILLING_ADDRESS = false;
    public static final boolean REQUIRE_UI = true;

    public static final int ENVIRONMENT = WalletConstants.ENVIRONMENT_TEST;
    public static final String CURRENCY_CODE = DataManager.getInstance().getShopCurrency();

    public static final boolean ALLOW_PREPAID_CARDS = true;


    public static final List<Integer> ALLOWED_PAYMENT_METHODS = Arrays.asList(
            WalletConstants.PAYMENT_METHOD_CARD,
            WalletConstants.PAYMENT_METHOD_TOKENIZED_CARD
    );
    public static final List<Integer> ALLOWED_CARD_NETWORKS = Arrays.asList(
            WalletConstants.CARD_NETWORK_AMEX,
            WalletConstants.CARD_NETWORK_DISCOVER,
            WalletConstants.CARD_NETWORK_INTERAC,
            WalletConstants.CARD_NETWORK_JCB,
            WalletConstants.CARD_NETWORK_MASTERCARD,
            WalletConstants.CARD_NETWORK_OTHER,
            WalletConstants.CARD_NETWORK_VISA
    );

    //TODO: Change "example with a gateway processor"
    static Pair<String, String> buildGateway() {
        return new Pair<String, String>("gateway", "example");
    }

    static Pair<String, String> buildMerchant() {
        return new Pair<String, String>("gatewayMerchantId", GraphClientManager.MERCHANT_ID);
    }

    static Pair<String, String> buildKey() {
        return new Pair<String, String>("publicKey", GraphClientManager.PUBLIC_KEY);
    }
}
