/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.views.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.TextView;

import com.shopify.buy3.Storefront;
import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.managers.interfaces.AddressesListCallback;
import com.teamextension.thehoodiezandroid.managers.interfaces.BaseCallback;
import com.teamextension.thehoodiezandroid.model.CurrentUser;

import java.util.ArrayList;

public class AddressListAdapter extends ArrayAdapter {

    private Context mContext;
    private ArrayList<Storefront.MailingAddress> mAddresses;

    private AddressesListCallback mCallback;

    public AddressListAdapter(@NonNull Context context, int resource) {
        super(context, resource);
        mContext = context;

        if(mContext instanceof AddressesListCallback) {
            mCallback = (AddressesListCallback) mContext;
        }

        mAddresses = CurrentUser.getInstance().getShippingAddresses();
    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if(convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.address_card_layout, null);
        }

        Storefront.MailingAddress address = mAddresses.get(position);
        if(address == null) {
            return convertView;
        }

        TextView label = convertView.findViewById(R.id.account_details_default_label);
        label.setText(String.valueOf(position + 1) + ".");

        EditText mFirstName = convertView.findViewById(R.id.account_details_firstName_value);
        EditText mLastName = convertView.findViewById(R.id.account_details_lastName_value);
        EditText mAddress1 = convertView.findViewById(R.id.account_details_address_1_value);
        EditText mAddress2 = convertView.findViewById(R.id.account_details_address_2_value);
        EditText mZip = convertView.findViewById(R.id.account_details_zip_value);
        EditText mCity = convertView.findViewById(R.id.account_details_city_value);
        EditText mCountry = convertView.findViewById(R.id.account_details_country_value);
        EditText mProvince = convertView.findViewById(R.id.account_details_province_value);
        EditText mCompany = convertView.findViewById(R.id.account_details_company_value);
        EditText mPhone = convertView.findViewById(R.id.account_details_phone_value);

        mFirstName.setText(address.getFirstName() == null || address.getFirstName().isEmpty() ? CurrentUser.getInstance().getFirstName() : address.getFirstName());
        mLastName.setText(address.getLastName() == null || address.getLastName().isEmpty() ? CurrentUser.getInstance().getLastName() : address.getLastName());
        mAddress1.setText(address.getAddress1() == null || address.getAddress1().isEmpty() ? "-" : address.getAddress1());
        mAddress2.setText(address.getAddress2() == null || address.getAddress2().isEmpty() ? "-" : address.getAddress2());
        mZip.setText(address.getZip() == null || address.getZip().isEmpty() ? "-" : address.getZip());
        mCity.setText(address.getCity() == null || address.getCity().isEmpty() ? "-" : address.getCity());
        mCountry.setText(address.getCountry() == null || address.getCountry().isEmpty() ? "United States" : address.getCountry());
        mCompany.setText(address.getCompany() == null || address.getCompany().isEmpty() ? "-" : address.getCompany());
        mProvince.setText((address.getProvince() == null || address.getProvince().isEmpty()) ? "Alabama" : address.getProvince());
        mPhone.setText(address.getPhone() == null || address.getPhone().isEmpty() ? "-" : address.getPhone());

        mFirstName.setEnabled(false);
        mLastName.setEnabled(false);
        mAddress1.setEnabled(false);
        mAddress2.setEnabled(false);
        mZip.setEnabled(false);
        mCity.setEnabled(false);
        mCountry.setEnabled(false);
        mCompany.setEnabled(false);
        mProvince.setEnabled(false);
        mPhone.setEnabled(false);

        TextView edit = convertView.findViewById(R.id.account_details_edit_link);
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCallback.updateNav(address.getId().toString());
            }
        });

        TextView setDefault = convertView.findViewById(R.id.set_as_default);
        setDefault.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DataManager.getInstance().updateDefaultAddress(address.getId().toString(), new BaseCallback() {
                    @Override
                    public void onResponse(int status) {
                        mCallback.updateDefault("Default Address Updated", true);
                    }

                    @Override
                    public void onFailure(String message) {
                        mCallback.updateDefault(message, false);
                    }
                });
            }
        });

        return convertView;
    }

    @Override
    public int getCount() {
        return mAddresses == null ? 0 : mAddresses.size();
    }

    @Nullable
    @Override
    public Object getItem(int position) {
        return mAddresses.get(position);
    }

    @NonNull
    @Override
    public Context getContext() {
        return mContext;
    }

    @Override
    public void notifyDataSetChanged() {
        mAddresses = CurrentUser.getInstance().getShippingAddresses();
        super.notifyDataSetChanged();
    }
}
