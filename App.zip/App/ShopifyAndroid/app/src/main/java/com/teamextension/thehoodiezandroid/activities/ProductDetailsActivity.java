/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.fragments.ProductDescriptionFragment;
import com.teamextension.thehoodiezandroid.fragments.ProductFragment;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.managers.DataManagerHelper;
import com.teamextension.thehoodiezandroid.model.ProductModel;
import com.teamextension.thehoodiezandroid.views.adapters.ProductPagerAdapter;

public class ProductDetailsActivity extends AbstractActivity{
    private ProductModel product;
    private TabLayout tabs ;
    private ViewPager pager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.single_product_layout);

        Bundle bundle = getIntent().getExtras();
        Toolbar mToolbar = findViewById(R.id.toolbar);

        ImageView cartBtn = mToolbar.findViewById(R.id.cart);
        cartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.setClickable(false);
                v.setFocusable(false);
                if(DataManagerHelper.getInstance().getCartProducts().size() == 0) {
                    ProductDetailsActivity.this.showOnUiThread("Cart Is Empty");
                    v.setClickable(true);
                    v.setFocusable(true);
                } else {
                    Intent navigate = new Intent(ProductDetailsActivity.this, CartActivity.class);
                    startActivity(navigate);
                    finish();
                }
            }
        });

        TextView title = findViewById(R.id.title);
        title.setText("");

        tabs = findViewById(R.id.submenu);
        pager = findViewById(R.id.viewPagerProduct);

        tabs.setupWithViewPager(pager);
        setUpViewPager(pager, bundle);
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        String productId = getIntent().getStringExtra("productId");
        product = DataManager.getInstance().getProductByID(productId);
    }

    public void setUpViewPager(ViewPager pager, Bundle bundle){
        ProductPagerAdapter adapter = new ProductPagerAdapter(getSupportFragmentManager(), new ProductPagerAdapter.OnFragmentChangedToggleFloatingActionButton() {
            @Override
            public void onFragmentChanged(Fragment fragment) {
            }
        });
        ProductFragment fragment = new ProductFragment();
        fragment.setArguments(bundle);
        adapter.addFragment(fragment, "Product");
        ProductDescriptionFragment fragment1 = new ProductDescriptionFragment();
        fragment1.setArguments(bundle);
        adapter.addFragment(fragment1, "Description");

        pager.setAdapter(adapter);
    }

}
