/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.wallet.AutoResolveHelper;
import com.google.android.gms.wallet.PaymentData;
import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.managers.DataManagerHelper;
import com.teamextension.thehoodiezandroid.managers.PaymentManager;
import com.teamextension.thehoodiezandroid.managers.interfaces.BaseCallback;
import com.teamextension.thehoodiezandroid.model.CartModel;
import com.teamextension.thehoodiezandroid.views.adapters.CartListAdapter;

import java.util.ArrayList;

public class CartActivity extends AbstractActivity implements CartListAdapter.CartCallback, View.OnClickListener {

    private static final String TAG = CartActivity.class.getSimpleName();
    private CartListAdapter mAdapter;
    private Button mGooglePayBtn;

    private PaymentManager mPaymentManager;

    boolean mElementClicked = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        //region Enable / Disable Google Pay
        mGooglePayBtn = findViewById(R.id.google_pay_btn);
        if(PaymentManager.ENABLE_GOOGLE_PAY) {
            mPaymentManager = new PaymentManager.Builder()
                    .getInstance()
                    .with(this)
                    .build();
            mPaymentManager.isReadyToPay(new BaseCallback() {
                @Override
                public void onResponse(final int status) {
                    runOnUiThread(() -> {
                        if (status == BaseCallback.RESULT_OK) {
                            mGooglePayBtn.setVisibility(View.VISIBLE);
                            mGooglePayBtn.setOnClickListener(CartActivity.this);
                        } else {
                            mGooglePayBtn.setVisibility(View.GONE);
                        }
                    });
                }

                @Override
                public void onFailure(final String message) {
                    runOnUiThread(() -> {
                        mGooglePayBtn.setVisibility(View.GONE);
                        Log.e(TAG, "onFailure: " + message);
                    });
                }
            });
        } else {
            mGooglePayBtn.setVisibility(View.GONE);
        }
        //endregion

        //region init toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView title = toolbar.findViewById(R.id.title);
        title.setText(DataManager.getInstance().getShopName().toUpperCase());
        //endregion

        ImageView backBtn = toolbar.findViewById(R.id.backBtn);
        backBtn.setOnClickListener(v -> CartActivity.this.finish());

        ListView itemsContainer = findViewById(R.id.productList);
        mAdapter = new CartListAdapter(this, R.layout.cart_list_item_layout);
        itemsContainer.setAdapter(mAdapter);
        itemsContainer.setOnItemClickListener((parent, view, position, id) -> {
            if(mElementClicked) {
                return;
            }

            mElementClicked = true;
            CartModel.CartItemWrapper item = (CartModel.CartItemWrapper) mAdapter.getItem(position);
            if(item == null) {
                showOnUiThread("Error navigating to product");
                return;
            }

            String productId = item.getProduct().getProductID();
            Intent navigate = new Intent(CartActivity.this, ProductDetailsActivity.class);
            navigate.putExtra("productId", productId);
            CartActivity.this.startActivity(navigate);

            CartActivity.this.finish();
        });

        Button checkoutBtn = findViewById(R.id.continue_button);
        checkoutBtn.setOnClickListener(v -> {
            Intent navigate = new Intent(CartActivity.this, PaymentActivity.class);
            startActivityForResult(navigate, RESULT_OK);
        });

        dataSetChanged();
    }

    public void dataSetChanged() {
        mAdapter.notifyDataSetChanged();

        int products = DataManagerHelper.getInstance().getCartProducts().size();
        String productSummaryText = getResources().getString(R.string.purchase_summary_placeholder_text);
        TextView summaryProductsNumber = findViewById(R.id.cart_summary_products_number);
        summaryProductsNumber.setText(String.format(productSummaryText, products) + (products == 1 ? "": "s"));

        TextView summaryProductsPrice = findViewById(R.id.cart_summary_products_price);
        summaryProductsPrice.setText(
                String.format(
                        getResources().getString(R.string.cart_summary_products_price_placeholder),
                        DataManager.getInstance().getProductsPrice(),
                        DataManager.getInstance().getShopCurrency()
                )
        );

        TextView summaryTotalPrice = findViewById(R.id.cart_summary_total_price);
        summaryTotalPrice.setText(
                String.format(
                        getResources().getString(R.string.cart_summary_products_price_placeholder),
                        DataManager.getInstance().getProductsPrice(),
                        DataManager.getInstance().getShopCurrency()
                )
        );
    }

    @Override
    public void notifyDataSetChanged() {
        runOnUiThread(CartActivity.this::dataSetChanged);
    }

    @Override
    public void onClick(View view) {
        view.setClickable(false);
        view.setFocusable(false);
        //region Handler for Google Pay Button events
        if(mPaymentManager != null) {
            mPaymentManager.createPaymentDataRequest()
                    .placePayment(CartActivity.this);
        }
        //endregion
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        mElementClicked = false;
        switch (requestCode) {
            case PaymentManager.LOAD_PAYMENT_DATA_REQUEST_CODE:
                switch (resultCode) {
                    case Activity.RESULT_OK:
                        //region Google Pay successful
                        PaymentData paymentData = PaymentData.getFromIntent(data);
                        if (paymentData != null && paymentData.getPaymentMethodToken() != null) {
                            CartActivity.this.handlePaymentSuccess(paymentData);
                        } else {
                            showOnUiThread("An error has occurred");
                        }
                        //endregion
                        break;

                    case Activity.RESULT_CANCELED:
                        Log.d(TAG, "onActivityResult: CANCELLED");
                        break;

                    case AutoResolveHelper.RESULT_ERROR:
                        //region Google Pay error encountered
                        Status status = AutoResolveHelper.getStatusFromIntent(data);
                        assert status != null;
                        Log.d(TAG, "onActivityResult: ERROR: " + status.getStatusMessage());
                        //endregion
                        break;

                    default:
                        break;
                }
                break;

            default:
                break;
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    private void handlePaymentSuccess(@NonNull PaymentData paymentData) {
        if(paymentData.getPaymentMethodToken() != null) {
            DataManager.getInstance().createCheckout(paymentData, new BaseCallback() {
                @Override
                public void onResponse(int status) {
                    CartActivity.this.finish();
                }

                @Override
                public void onFailure(String message) {
                    Log.e(TAG, "onFailure: " + message );
                    CartActivity.this.showOnUiThread("An unknown error has occurred");
                    CartActivity.this.runOnUiThread(() -> {
                        mGooglePayBtn.setClickable(true);
                        mGooglePayBtn.setFocusable(true);
                    });
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        mPaymentManager.closeConnection();
        super.onDestroy();
    }
}
