/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.views.adapters;

import android.app.Activity;
import android.content.Context;
import android.graphics.Paint;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.teamextension.thehoodiezandroid.CommonUtils;
import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.model.CartModel;
import com.teamextension.thehoodiezandroid.managers.DataManagerHelper;
import com.teamextension.thehoodiezandroid.model.ProductModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CartListAdapter extends ArrayAdapter {

    private Context mContext;
    private CartCallback mCallback;
    private DisplayMetrics mDm;
    private ArrayList<CartModel.CartItemWrapper> mItems;

    public CartListAdapter(@NonNull Context context, int resource) {
        super(context, resource);

        mContext = context;
        if(mContext instanceof CartCallback) {
            mCallback = (CartCallback) mContext;
        }

        mDm = new DisplayMetrics();
        ((Activity) mContext).getWindowManager().getDefaultDisplay().getMetrics(mDm);

        mItems = DataManagerHelper.getInstance().getCartProducts();
    }

    @Override
    public int getCount() {
        return mItems != null ? mItems.size() : 0;
    }

    @Nullable
    @Override
    public Object getItem(int position) {
        return mItems.get(position);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Holder holder;
        if(convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.cart_list_item_layout, null);
            holder = new Holder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (Holder) convertView.getTag();
        }

        CartModel.CartItemWrapper item = mItems.get(position);
        holder.setData(item);

        return convertView;
    }

    @Override
    public void notifyDataSetChanged() {
        mItems = DataManagerHelper.getInstance().getCartProducts();
        super.notifyDataSetChanged();
    }

    private class Holder {
        private static final String TAG = "Holder";
        private ImageView mImage = null;
        private TextView mTitle = null;
        private LinearLayout mOptionsContainer = null;
        private ImageView mRemoveBtn = null;
        private TextView mOldPrice = null;
        private TextView mPrice = null;
        private TextView mLabel = null;

        Holder(View view) {
            mImage = view.findViewById(R.id.productImage);
            mTitle = view.findViewById(R.id.productTitle);
            mOptionsContainer = view.findViewById(R.id.productOptionsContainer);
            mRemoveBtn = view.findViewById(R.id.remove_button);
            mOldPrice = view.findViewById(R.id.productOldPrice);
            mPrice = view.findViewById(R.id.productPrice);
            mLabel = view.findViewById(R.id.offer_label);
        }

        void setData(CartModel.CartItemWrapper item) {
            int imageWidth = mDm.widthPixels / 3;

            ProductModel product = DataManager.getInstance().getProductByID(item.getProduct().getProductID());
            Picasso.with(mContext)
                    .load(product.getImages()[0])
                    .resize(imageWidth, imageWidth / 3 + imageWidth)
                    .centerInside()
                    .placeholder(R.drawable.ic_image_black_24dp)
                    .into(mImage);

            mTitle.setText(product.getTitle());
            if(item.getProduct().getOldPrice() != null) {
                mOldPrice.setText(
                        String.format(
                                mOldPrice.getText().toString(),
                                item.getProduct().getOldPrice().floatValue(),
                                DataManager.getInstance().getShopCurrency()
                        )
                );
                mOldPrice.setPaintFlags(mOldPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                if(item.getProduct().isAvailableForSale()){
                    mLabel.setVisibility(View.VISIBLE);
                } else{
                    mLabel.setVisibility(View.INVISIBLE);
                }
            } else {
                mOldPrice.setVisibility(View.INVISIBLE);
            }

            mPrice.setText(
                    String.format(
                            mPrice.getText().toString(),
                            item.getProduct().getPrice().floatValue(),
                            DataManager.getInstance().getShopCurrency()
                    )
            );

            mRemoveBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DataManagerHelper.getInstance().removeFromCart(item.getProduct().getID());
                    CartListAdapter.this.mCallback.notifyDataSetChanged();
                }
            });

            mOptionsContainer.removeAllViews();

            HashMap<String, String> options = item.getProduct().getSelectedOptions();
            for(Map.Entry<String, String> s1: options.entrySet()) {
                String s = s1.getKey() + ": " + s1.getValue();
                Log.d(TAG, "setData: " + s);
                mOptionsContainer.addView(CommonUtils.createItemOptionView(s1.getKey() + ": " + s1.getValue(), mContext));
            }
        }
    }

    public interface CartCallback {
        void notifyDataSetChanged();
    }
}
