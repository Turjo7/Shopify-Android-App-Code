/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.managers.interfaces;

import android.support.annotation.UiThread;

/**
 * Created by bbogdan on 26.03.2018.
 */

public interface NavigationToggleEvent {
    @UiThread
    void enableNavigation();
    @UiThread
    void disableNavigation();
}
