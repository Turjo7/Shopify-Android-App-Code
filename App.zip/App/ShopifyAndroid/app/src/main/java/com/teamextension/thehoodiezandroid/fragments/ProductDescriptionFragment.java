/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.model.ProductModel;

public class ProductDescriptionFragment extends Fragment{

    private ProductModel mProduct = null;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View descriptionPage = inflater.inflate(R.layout.fragment_product_description,container, false);

        WebView desc = (WebView) descriptionPage.findViewById(R.id.product_description);
        if(mProduct != null) {
            desc.loadDataWithBaseURL(null, mProduct.getDescription(), "text/html", "utf-8", null);
        }

        return descriptionPage;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        Bundle args = getArguments();

        if(args != null) {
            String pId = args.getString("productId");

            if(pId != null && !pId.isEmpty()) {
                mProduct = DataManager.getInstance().getProductByID(pId);
            }
        }
    }
}
