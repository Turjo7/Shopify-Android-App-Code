/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.fragments;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.shopify.buy3.Storefront;
import com.teamextension.thehoodiezandroid.CommonUtils;
import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.managers.DataManagerHelper;
import com.teamextension.thehoodiezandroid.managers.interfaces.BaseCallback;
import com.teamextension.thehoodiezandroid.managers.interfaces.OnNavigationOccurred;
import com.teamextension.thehoodiezandroid.model.CurrentUser;

import org.w3c.dom.Text;

import java.util.Observable;
import java.util.Observer;

public class AddressFragment extends AbstractCheckoutFragment {//implements Observer {

    private EditText emailInputField = null;
    private EditText firstNameInputField = null;
    private EditText lastNameInputField = null;
    private EditText address1InputField = null;
    private EditText address2InputField = null;
    private EditText cityInputField = null;
    private EditText countryInputField = null;
    private EditText zipInputField = null;
    private EditText companyInputField = null;
    private EditText provinceInputField = null;
    private EditText phoneInputField = null;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_shipping_address, null);

        TextView screenLabel = view.findViewById(R.id.shipping_address_label);

        this.emailInputField = view.findViewById(R.id.shipping_address_email_input);
        this.firstNameInputField = view.findViewById(R.id.shipping_address_firstname_input);
        this.lastNameInputField = view.findViewById(R.id.shipping_address_lastname_input);
        this.phoneInputField = view.findViewById(R.id.shipping_address_phone_input);
        this.address1InputField = view.findViewById(R.id.shipping_address_address1_input);
        this.address2InputField = view.findViewById(R.id.shipping_address_address2_input);
        this.cityInputField = view.findViewById(R.id.shipping_address_city_input);
        this.companyInputField = view.findViewById(R.id.shipping_address_company_input);
        this.provinceInputField = view.findViewById(R.id.shipping_address_province_input);
        this.countryInputField = view.findViewById(R.id.shipping_address_country_input);
        this.zipInputField = view.findViewById(R.id.shipping_address_zip_input);

        switch (this.fragmentIndex) {
            case 0:
                screenLabel.setText(R.string.shipping_address_text);
                break;

            case 1:
                screenLabel.setText(R.string.billing_address_text);
                break;

            default:
                break;
        }


        if(!CurrentUser.getInstance().getAccessToken().isEmpty() || this.fragmentIndex == 1) {
            this.emailInputField.setEnabled(false);

        }
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        if(checkFields()) {
            setupData(DataManager.getInstance());
        }
        super.onViewCreated(view, savedInstanceState);
    }

    private boolean checkFields() {
        return this.emailInputField != null &&
                this.firstNameInputField != null &&
                this.lastNameInputField != null &&
                this.phoneInputField != null &&
                this.address1InputField != null &&
                this.address2InputField != null &&
                this.companyInputField != null &&
                this.cityInputField != null &&
                this.countryInputField != null &&
                this.provinceInputField != null &&
                this.zipInputField != null;
    }

    @Override
    public boolean validateFields() {
        boolean isValid = true;

        String email = getText(this.emailInputField);
        if (email.isEmpty()) {
            isValid = false;
            this.emailInputField.setError("Field cannot be empty");
        }

        String firstName = getText(this.firstNameInputField);
        if (firstName.isEmpty()) {
            isValid = false;
            this.firstNameInputField.setError("Field cannot be empty");
        }

        String lastName = getText(this.lastNameInputField);
        if (lastName.isEmpty()) {
            isValid = false;
            this.lastNameInputField.setError("Field cannot be empty");
        }

        String address1 = getText(this.address1InputField);
        if (address1.isEmpty()) {
            isValid = false;
            this.address1InputField.setError("An address must be provided");
        }

        String city = getText(this.cityInputField);
        if (city.isEmpty()) {
            isValid = false;
            this.cityInputField.setError("Field cannot be empty");
        }

        String province = getText(this.provinceInputField);
        if (province.isEmpty()) {
            isValid = false;
            this.provinceInputField.setError("Field cannot be empty");
        }

        String country = getText(this.countryInputField);
        if (country.isEmpty()) {
            isValid = false;
            this.countryInputField.setError("Field cannot be empty" );
        }

        String zip = getText(this.zipInputField);
        if (zip.isEmpty()) {
            isValid = false;
            this.zipInputField.setError(zip.isEmpty() ? "Field cannot be empty" : "Invalid zip/postal code");
        }

        String phone = getText(this.phoneInputField);
        if (zip.isEmpty()) {
            isValid = false;
            this.phoneInputField.setError(phone.isEmpty() ? "Field cannot be empty" : "Invalid phone number");
        }

        return isValid;
    }

    public Storefront.MailingAddress getAddress() {
        Activity a = AddressFragment.this.getActivity();

        final Storefront.MailingAddress resultAddress = new Storefront.MailingAddress();
        if (a != null) {
            a.runOnUiThread(() -> {
                if (CurrentUser.getInstance().getAccessToken().isEmpty()) {
                    if (AddressFragment.this.fragmentIndex == 0) {
                        CurrentUser.getInstance().setEmail(AddressFragment.this.getText(AddressFragment.this.emailInputField));
                    }
                }

                String add1 = AddressFragment.this.getText(AddressFragment.this.address1InputField);
                String add2 = AddressFragment.this.getText(AddressFragment.this.address2InputField);

                resultAddress.setFirstName(AddressFragment.this.getText(AddressFragment.this.firstNameInputField))
                        .setLastName(AddressFragment.this.getText(AddressFragment.this.lastNameInputField))
                        .setPhone(AddressFragment.this.getText(AddressFragment.this.phoneInputField))
                        .setCompany(AddressFragment.this.getText(AddressFragment.this.companyInputField))
                        .setAddress1(!add1.isEmpty() ? add1 : (!add2.isEmpty() ? add2 : ""))
                        .setAddress2(add2)
                        .setCity(AddressFragment.this.getText(AddressFragment.this.cityInputField))
                        .setProvince(AddressFragment.this.getText(AddressFragment.this.provinceInputField))
                        .setZip(AddressFragment.this.getText(AddressFragment.this.zipInputField))
                        .setCountry(AddressFragment.this.getText(AddressFragment.this.countryInputField));
            });
        }
        return resultAddress;
    }

    @Override
    public void setupData(DataManager manager) {
        String email = null;
        String firstName = null;
        String lastName = null;
        String phone = null;
        String address1 = null;
        String address2 = null;
        String city = null;
        String company = null;
        String province = null;
        String country = null;
        String zip = null;

        CurrentUser user = CurrentUser.getInstance();
        Storefront.Checkout checkout = manager.getCheckout();
        Storefront.MailingAddress address = (checkout != null) ? checkout.getShippingAddress() : null;

        switch (this.fragmentIndex) {
            case 0:
                email = (user.getEmail() != null) ? user.getEmail() : "";
                break;
            case 1:
                email = (checkout != null && checkout.getEmail() != null) ? checkout.getEmail() : "";
        }

        final String resultEmail = email;
        Activity a = AddressFragment.this.getActivity();
        if(a != null) {
            a.runOnUiThread(() -> {
                AddressFragment.this.emailInputField.setText(resultEmail);
            });
        }

        if (!this.fieldsEmpty()) {
            return;
        }

        if (this.fragmentIndex == 0) {
            firstName = (user.getFirstName() != null) ? user.getFirstName() : "";
            lastName = (user.getLastName() != null) ? user.getLastName() : "";
            phone = (user.getAddress() != null && user.getAddress().getPhone() != null) ? user.getAddress().getPhone() : "";
            address1 = (user.getAddress() != null && user.getAddress().getAddress1() != null) ? user.getAddress().getAddress1() : "";
            address2 = (user.getAddress() != null && user.getAddress().getAddress2() != null) ? user.getAddress().getAddress2() : "";
            city = (user.getAddress() != null && user.getAddress().getCity() != null) ? user.getAddress().getCity() : "";
            company = (user.getAddress() != null && user.getAddress().getCompany() != null) ? user.getAddress().getCompany() : "";
            province = (user.getAddress() != null && user.getAddress().getProvince() != null) ? user.getAddress().getProvince() : "";
            country = (user.getAddress() != null && user.getAddress().getCountry() != null) ? user.getAddress().getCountry() : "";
            zip = (user.getAddress() != null && user.getAddress().getZip() != null) ? user.getAddress().getZip() : "";
        } else {
            firstName = (address != null && address.getFirstName() != null) ? address.getFirstName() : "";
            lastName = (address != null && address.getLastName() != null) ? address.getLastName() : "";
            phone = (address != null && address.getPhone() != null) ? address.getPhone() : "";
            address1 = (address != null && address.getAddress1() != null) ? address.getAddress1() : "";
            address2 = (address != null && address.getAddress2() != null) ? address.getAddress2() : "";
            city = (address != null && address.getCity() != null) ? address.getCity() : "";
            company = (address != null && address.getCompany() != null) ? address.getCompany() : "";
            province = (address != null && address.getProvince() != null) ? address.getProvince() : "";
            country = (address != null && address.getCountry() != null) ? address.getCountry() : "";
            zip = (address != null && address.getZip() != null) ? address.getZip() : "";
        }

        final String finalEmail = email;
        final String finalFirstName = (!firstName.isEmpty() && !firstName.toLowerCase().contentEquals(this.firstNameInputField.getText().toString().toLowerCase())) ?
                firstName :
                this.firstNameInputField.getText().toString();
        final String finalLastName = (!lastName.isEmpty() && !lastName.toLowerCase().contentEquals(this.lastNameInputField.getText().toString().toLowerCase())) ?
                lastName :
                this.lastNameInputField.getText().toString();
        final String finalPhone = (!phone.isEmpty() && !phone.toLowerCase().contentEquals(this.phoneInputField.getText().toString().toLowerCase())) ?
                phone :
                this.phoneInputField.getText().toString();
        final String finalCompany = (!company.isEmpty() && !company.toLowerCase().contentEquals(this.companyInputField.getText().toString().toLowerCase())) ?
                company :
                this.companyInputField.getText().toString();
        final String finalAddress1 = (!address1.isEmpty() && !address1.toLowerCase().contentEquals(this.address1InputField.getText().toString().toLowerCase())) ?
                address1 :
                this.address1InputField.getText().toString();
        final String finalAddress2 = (!address2.isEmpty() && !address2.toLowerCase().contentEquals(this.address2InputField.getText().toString().toLowerCase())) ?
                address2 :
                this.address2InputField.getText().toString();
        final String finalCity = (!city.isEmpty() && !city.toLowerCase().contentEquals(this.cityInputField.getText().toString().toLowerCase())) ?
                city :
                this.cityInputField.getText().toString();
        final String finalCountry = (!country.isEmpty() && !country.toLowerCase().contentEquals(this.countryInputField.getText().toString().toLowerCase())) ?
                country :
                this.countryInputField.getText().toString();
        final String finalProvince = (!province.isEmpty() && !province.toLowerCase().contentEquals(this.provinceInputField.getText().toString().toLowerCase())) ?
                province :
                this.provinceInputField.getText().toString();
        final String finalZip = (!zip.isEmpty() && !zip.toLowerCase().contentEquals(this.zipInputField.getText().toString().toLowerCase())) ?
                zip :
                this.zipInputField.getText().toString();

        Activity a1 = AddressFragment.this.getActivity();
        if (a1 != null) {
            a1.runOnUiThread(() -> {
                AddressFragment.this.emailInputField.setText(finalEmail);
                AddressFragment.this.firstNameInputField.setText(finalFirstName);
                AddressFragment.this.lastNameInputField.setText(finalLastName);
                AddressFragment.this.phoneInputField.setText(finalPhone);
                AddressFragment.this.address1InputField.setText(finalAddress1);
                AddressFragment.this.address2InputField.setText(finalAddress2);
                AddressFragment.this.cityInputField.setText(finalCity);
                AddressFragment.this.companyInputField.setText(finalCompany);
                AddressFragment.this.provinceInputField.setText(finalProvince);
                AddressFragment.this.countryInputField.setText(finalCountry);
                AddressFragment.this.zipInputField.setText(finalZip);
            });
        }
    }

    private boolean fieldsEmpty() {
        return this.checkFields() &&
                this.firstNameInputField.getText().toString().isEmpty() &&
                this.lastNameInputField.getText().toString().isEmpty() &&
                this.address1InputField.getText().toString().isEmpty() &&
                this.cityInputField.getText().toString().isEmpty() &&
                this.countryInputField.getText().toString().isEmpty() &&
                this.provinceInputField.getText().toString().isEmpty() &&
                this.zipInputField.getText().toString().isEmpty();
    }

    @Override
    public void showErrors(String error) {

        if(error.toLowerCase().contains("email")) {
            this.emailInputField.setError(error);
        } else if(error.toLowerCase().contains("first")) {
            this.firstNameInputField.setError(error);
        } else if(error.toLowerCase().contains("last")) {
            this.lastNameInputField.setError(error);
        } else if(error.toLowerCase().contains("phone")) {
            this.phoneInputField.setError(error);
        } else if(error.toLowerCase().contains("address")) {
            this.address1InputField.setError(error);
        } else if(error.toLowerCase().contains("city")) {
            this.cityInputField.setError(error);
        } else if(error.toLowerCase().contains("province")) {
            this.provinceInputField.setError(error);
        } else if(error.toLowerCase().contains("zip")) {
            this.zipInputField.setError(error);
        } else if(error.toLowerCase().contains("country")) {
            this.countryInputField.setError(error);
        }
    }
}
