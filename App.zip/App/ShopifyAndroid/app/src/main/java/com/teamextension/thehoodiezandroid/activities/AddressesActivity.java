/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.managers.interfaces.AddressesListCallback;
import com.teamextension.thehoodiezandroid.managers.interfaces.BaseCallback;
import com.teamextension.thehoodiezandroid.views.adapters.AddressListAdapter;

import static com.teamextension.thehoodiezandroid.activities.AddressUpdateActivity.ADDRESS_ID_KEY;

public class AddressesActivity extends AbstractActivity implements AddressesListCallback {

    private boolean newDefault = false;

    private Button mAddAddress;
    private ListView mContainer;
    private TextView mMessageContainer;
    private AddressListAdapter mAdapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addresses);

        Toolbar toolbar = findViewById(R.id.toolbar);
        ImageView backButton = toolbar.findViewById(R.id.backButton);
        TextView title = toolbar.findViewById(R.id.title);
        title.setText("");
        backButton.setVisibility(View.VISIBLE);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        mMessageContainer = findViewById(R.id.account_details_no_addresses_message);
        mContainer = findViewById(R.id.account_details_addresses_container);
        mAddAddress = findViewById(R.id.account_details_add_address_button);
        mAddAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent navigate = new Intent(AddressesActivity.this, AddressUpdateActivity.class);
                startActivityForResult(navigate, AccountActivity.RESULT_CREATE);
            }
        });

        mAdapter = new AddressListAdapter(this, R.layout.address_card_layout);
        mContainer.setAdapter(mAdapter);

        if(mAdapter.getCount() != 0) {
            mContainer.setVisibility(View.VISIBLE);
            mMessageContainer.setVisibility(View.GONE);
        }
        DataManager.getInstance().userAddresses(new BaseCallback() {
            @Override
            public void onResponse(int status) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mAdapter.notifyDataSetChanged();
                        if(mAdapter.getCount() != 0) {
                            mContainer.setVisibility(View.VISIBLE);
                            mMessageContainer.setVisibility(View.GONE);
                        }
                    }
                });
            }

            @Override
            public void onFailure(String message) {
                AddressesActivity.this.showOnUiThread(message);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        mAdapter.notifyDataSetChanged();

        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void updateDefault(String message, boolean update) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(update) {
                    AddressesActivity.this.newDefault = true;
                    Toast.makeText(AddressesActivity.this, message, Toast.LENGTH_SHORT).show();
                    AddressesActivity.this.finish();
                } else {
                    Toast.makeText(AddressesActivity.this, message, Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    public void updateNav(String addressId) {
        Intent navigate = new Intent(AddressesActivity.this, AddressUpdateActivity.class);
        navigate.putExtra(AddressUpdateActivity.ADDRESS_ID_KEY, addressId);
        startActivityForResult(navigate, 1);
    }

    @Override
    public void onBackPressed() {
        Intent back = AddressesActivity.this.getIntent();
        back.putExtra(ADDRESS_ID_KEY, AddressesActivity.this.newDefault);
        setResult(AccountActivity.RESULT_UPDATE, back);

        super.onBackPressed();
    }
}