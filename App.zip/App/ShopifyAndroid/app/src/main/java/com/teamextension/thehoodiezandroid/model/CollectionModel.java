/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.model;

import com.shopify.buy3.Storefront;
import com.shopify.graphql.support.ID;

import org.joda.time.DateTime;

import java.util.ArrayList;

public class CollectionModel {

    private ID mID;
    private String mTitle;
    private DateTime mUpdatedAt;
    private ArrayList<ProductModel> mPreviewProducts = new ArrayList<ProductModel>();

    private CollectionModel(ID id, String title, DateTime updatedAt) {
        this.mID = id;
        this.mTitle = title;
        this.mUpdatedAt = updatedAt;
        this.mPreviewProducts = new ArrayList<ProductModel>();
    }

    public CollectionModel(Storefront.CollectionEdge collectionEdge) {
        Storefront.Collection node = collectionEdge.getNode();
        mID = node.getId();
        mTitle = node.getTitle();

        mUpdatedAt = node.getUpdatedAt();

        Storefront.ProductConnection products = node.getProducts();
        for(Storefront.ProductEdge edge: products.getEdges()) {
            ProductModel newProduct = new ProductModel(edge, mID.toString());

            mPreviewProducts.add(newProduct);
        }
    }

    public ID getID() {
        return mID;
    }

    public String getTitle() {
        return mTitle;
    }

    public DateTime getUpdatedAt() {
        return mUpdatedAt;
    }

    public ArrayList<ProductModel> getPreviewProducts() {
        return mPreviewProducts;
    }

    private void setPreview(ArrayList<ProductModel> products) {
        this.mPreviewProducts = products;
    }

    public static CollectionModel buildCollection(CollectionModel collectionModel, ArrayList<ProductModel> collectionProducts) {
        CollectionModel newCollection = new CollectionModel(collectionModel.getID(), collectionModel.getTitle(), collectionModel.getUpdatedAt());
        newCollection.setPreview(collectionProducts);

        return newCollection;
    }
}
