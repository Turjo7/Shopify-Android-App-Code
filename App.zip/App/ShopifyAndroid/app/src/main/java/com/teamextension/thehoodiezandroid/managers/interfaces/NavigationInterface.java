/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.managers.interfaces;

/**
 * Created by Ripan Andra on 12/13/2017.
 */

public interface NavigationInterface {

    void navigateToProduct(String productId);

    void navigateToCollection(String collectionId);

}
