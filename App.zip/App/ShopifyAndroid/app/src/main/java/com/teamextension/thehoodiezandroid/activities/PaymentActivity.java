/*
 * Copyright © 2018-present, MNK Group. All rights reserved.
 */

package com.teamextension.thehoodiezandroid.activities;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.teamextension.thehoodiezandroid.R;
import com.teamextension.thehoodiezandroid.managers.DataManager;
import com.teamextension.thehoodiezandroid.managers.interfaces.BaseCallback;
import com.teamextension.thehoodiezandroid.managers.interfaces.NavigationToggleEvent;
import com.teamextension.thehoodiezandroid.managers.interfaces.OnNavigationOccurred;
import com.teamextension.thehoodiezandroid.model.CurrentUser;
import com.teamextension.thehoodiezandroid.views.PaymentViewPager;

import java.io.IOException;

public class PaymentActivity extends AbstractActivity implements PaymentViewPager.OnPaymentOccurred, OnNavigationOccurred, View.OnClickListener, NavigationToggleEvent {

    private PaymentViewPager viewPager = null;
    private TabLayout tabLayout = null;
    private TextView backLink = null;
    private TextView nextLink = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        //region  Toolbar setup
        Toolbar toolbar = findViewById(R.id.toolbar);
        ImageView backButton = toolbar.findViewById(R.id.backBtn);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PaymentActivity.this.finish();
            }
        });

        TextView title = toolbar.findViewById(R.id.title);
        title.setText(DataManager.getInstance().getShopName().toUpperCase());
        //endregion

        viewPager = findViewById(R.id.viewPager);
        tabLayout = findViewById(R.id.submenu);
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(final TabLayout.Tab tab) {
                changeButtons(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        this.backLink = findViewById(R.id.shipping_address_billing_link);
        this.nextLink = findViewById(R.id.shipping_address_payment_link);

        if(!CurrentUser.getInstance().getAccessToken().isEmpty()) {
            DataManager.getInstance().createCheckout(new BaseCallback() {
                @Override
                public void onResponse(int status) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            PaymentActivity.this.init();
                        }
                    });
                }

                @Override
                public void onFailure(String message) {
                    PaymentActivity.this.showOnUiThread(message);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            PaymentActivity.this.init();
                        }
                    });
                }
            });
        } else {
            PaymentActivity.this.init();
        }
    }

    private void init() {
        PaymentViewPager.PagerAdapter adapter = new PaymentViewPager.PagerAdapter(getSupportFragmentManager());
        tabLayout.setupWithViewPager(viewPager);
        viewPager.setAdapter(adapter);

        this.backLink.setOnClickListener(PaymentActivity.this);
        this.nextLink.setOnClickListener(PaymentActivity.this);
    }

    private void changeButtons(int position) {
        switch (position) {
            case 0:
                PaymentActivity.this.backLink.setText(R.string.return_to_cart_text);
                PaymentActivity.this.nextLink.setText(R.string.continue_to_billing_text);
                break;

            case 1:
                PaymentActivity.this.backLink.setText(R.string.return_to_shipping_text);
                PaymentActivity.this.nextLink.setText(R.string.continue_to_payment_text);
                break;

            case 2:
                PaymentActivity.this.backLink.setText(R.string.return_to_billing_text);
                PaymentActivity.this.nextLink.setText(R.string.place_order_text);
                break;

            default:
        }
    }

    @Override
    public void onBackPressed() {
        DataManager.getInstance().resetCheckout();
        super.onBackPressed();
    }

    @Override
    public void onPaymentOccurred(ResponseData responseData) {
        int code = responseData.code();
        String message = "";
        switch (code) {
            case ResponseData.ResponseCodes.STATUS_OK:
                message = "Payment placed successfully";
                break;

            case ResponseData.ResponseCodes.STATUS_FAIL:
            case ResponseData.ResponseCodes.STATUS_DISABLED:
                message = getMessage(responseData);
                break;
        }

        if(!message.isEmpty()) {
            PaymentActivity.this.showOnUiThread(message);
        }

        if(code == ResponseData.ResponseCodes.STATUS_OK) {
            PaymentActivity.this.runOnUiThread(() -> {
                DataManager.getInstance().resetCheckout();
                PaymentActivity.this.setResult(RESULT_OK);
                PaymentActivity.this.finish();
            });
        } else {
            PaymentActivity.this.runOnUiThread(PaymentActivity.this::enableNavigation);
        }
    }

    private String getMessage(ResponseData responseData) {
        String result = null;
        if(responseData.data() instanceof IOException) {
            result = ((IOException) responseData.data()).getLocalizedMessage();
        } else if(responseData.data() instanceof String) {
            result = (String) responseData.data();
        } else {
            result = "Unknown error occurred";
        }

        return result;
    }

    @Override
    public void onNavigationOccurred(Direction direction) {
        switch (direction) {
            case CUSTOMER:
                viewPager.setCurrentItem(0);
                break;
            case SHIPPING:
                viewPager.setCurrentItem(1);
                break;
        }
    }

    @Override
    public void onClick(View v) {
        PaymentActivity.this.runOnUiThread(PaymentActivity.this::disableNavigation);
        int currentItem = viewPager.getCurrentItem();

        switch (v.getId()) {
            case R.id.shipping_address_billing_link:
                if(currentItem == 0) {
                    PaymentActivity.this.onBackPressed();
                } else {
                    viewPager.setCurrentItem(currentItem - 1);
                    changeButtons(currentItem - 1);
                }
                PaymentActivity.this.enableNavigation();
                break;

            case R.id.shipping_address_payment_link:
                if(currentItem != 2) {
                    viewPager.validateFields();
                } else {
                    viewPager.pay();
                }
                break;
        }
    }

    @Override
    public void enableNavigation() {
        PaymentActivity.this.runOnUiThread(() -> {
            PaymentActivity.this.backLink.setClickable(true);
            PaymentActivity.this.backLink.setFocusable(true);
            PaymentActivity.this.nextLink.setClickable(true);
            PaymentActivity.this.nextLink.setFocusable(true);
        });
    }

    @Override
    public void disableNavigation() {
        PaymentActivity.this.runOnUiThread(() -> {
            PaymentActivity.this.backLink.setClickable(false);
            PaymentActivity.this.backLink.setFocusable(false);
            PaymentActivity.this.nextLink.setClickable(false);
            PaymentActivity.this.nextLink.setFocusable(false);
        });
    }
}